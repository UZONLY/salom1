package com.example.anime_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
