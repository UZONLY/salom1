import 'package:flutter/material.dart';
import 'presentation/pages/main_menu.dart';

class AnimelarTVApp extends StatelessWidget {
  const AnimelarTVApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Animelar TV',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFF252831),
        primaryColor: const Color(0xFFF29824),
        textTheme: const TextTheme(bodyMedium: TextStyle(color: Colors.white)),
      ),
      home: const MainMenu(),
    );
  }
}