// lib/services/api_service.dart
// ⭐️⭐️⭐️ TO'LIQ YANGILANGAN VA TUZATILGAN FAYL ⭐️⭐️⭐️

import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String baseUrl = 'http://45.92.173.11:3000';
  static bool get _offlineMode {
    return false; // <-- Haqiqiy serverga ulanish uchun
  }

  // Demo foydalanuvchilar (server.py ga mos)
  static final Map<String, Map<String, dynamic>> _demoUsers = {
    'shodiyor1@example.com': {
      'password': 'shodiyor1!',
      'id': '6526385624', // Super Admin ID
      'balance': 1000000.0,
      'name': 'Shodiyor (Super Admin)',
      'email': 'shodiyor1@example.com',
      'purchasedAnimes': [],
    },
    'user1@example.com': {
      'password': '123456',
      'id': 'user_001',
      'balance': 15000.0,
      'name': 'User One',
      'email': 'user1@example.com',
      'purchasedAnimes': [],
    },
  };

  // --- Token va User saqlash ---
  static Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  static Future<void> saveUser(Map<String, dynamic> user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('saved_user', jsonEncode(user));
  }

  static Future<Map<String, dynamic>?> getSavedUser() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = prefs.getString('saved_user');
    if (jsonStr == null) return null;
    try {
      return jsonDecode(jsonStr);
    } catch (_) {
      return null;
    }
  }

  // --- AUTH ---
  static Future<Map<String, dynamic>?> register(
      String name, String email, String password) async {
    if (_offlineMode) {
      if (_demoUsers.containsKey(email)) {
        return {'ok': false, 'detail': 'user_exists'};
      }
      final newUser = {
        'id': 'user_${DateTime.now().millisecondsSinceEpoch}',
        'balance': 5000.0,
        'name': name,
        'email': email,
        'purchasedAnimes': [],
      };
      _demoUsers[email] = {'password': password, ...newUser};
      await saveUser(newUser);
      await saveToken("demo_token_$email");
      return {'ok': true, 'user': newUser, 'token': "demo_token_$email"};
    }
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/register'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(
                {'name': name, 'email': email, 'password': password}),
          )
          .timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['ok'] == true) {
        if (data['user'] != null) await saveUser(data['user']);
        if (data['token'] != null) await saveToken(data['token']);
      }
      return data;
    } catch (e) {
      return {'ok': false, 'detail': 'network_error', 'message': e.toString()};
    }
  }

  static Future<Map<String, dynamic>?> login(
      String email, String password) async {
    if (_offlineMode) {
      final u = _demoUsers[email];
      if (u == null) return {'ok': false, 'detail': 'invalid_credentials'};
      if (u['password'] != password)
        return {'ok': false, 'detail': 'invalid_credentials'};
      final user = {...u};
      user.remove('password');
      await saveUser(user);
      await saveToken("demo_token_${user['id']}");
      return {'ok': true, 'user': user, 'token': "demo_token_${user['id']}"};
    }
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/login'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'email': email, 'password': password}),
          )
          .timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['ok'] == true) {
        if (data['user'] != null) await saveUser(data['user']);
        if (data['token'] != null) await saveToken(data['token']);
      }
      return data;
    } catch (e) {
      final u = _demoUsers[email]; // Offline fallback
      if (u != null && u['password'] == password) {
        final user = {...u};
        user.remove('password');
        await saveUser(user);
        await saveToken("demo_token_${user['id']}");
        return {'ok': true, 'user': user, 'token': "demo_token_${user['id']}"};
      }
      return {'ok': false, 'detail': 'network_error', 'message': e.toString()};
    }
  }

  // --- PAYMENT (TSPay) ---
  static Future<Map<String, dynamic>?> createPayment(
      String userId, double amount) async {
    if (_offlineMode) {
      return {
        "ok": true,
        "payment": {
          "id": "demo_payment_${DateTime.now().millisecondsSinceEpoch}",
          "paymentUrl": "https://tspay.uz/demo",
        }
      };
    }
    final token = await getToken();
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/payment/create'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token'
        },
        body: jsonEncode({
          'userId': userId,
          'amount': amount,
          'description': 'Anime TV uchun hisob to\'ldirish'
        }),
      );
      return jsonDecode(res.body);
    } catch (e) {
      return {'ok': false, 'detail': e.toString()};
    }
  }

  static Future<Map<String, dynamic>?> purchaseAnime(
      String userId, String animeId) async {
    if (_offlineMode) {
      final demoUser = _demoUsers.values.firstWhere((u) => u['id'] == userId);
      if (demoUser['balance'] >= 2900) {
        demoUser['balance'] -= 2900;
        (demoUser['purchasedAnimes'] as List).add(animeId);
        await saveUser(demoUser);
        return {
          'ok': true,
          'purchased': true,
          'newBalance': demoUser['balance']
        };
      } else {
        return {'ok': false, 'detail': 'insufficient_balance'};
      }
    }
    final token = await getToken();
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/anime/$animeId/purchase'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token'
        },
        body: jsonEncode({'userId': userId}),
      );
      final data = jsonDecode(res.body);
      if (data['ok'] == true && data['purchased'] == true) {
        final user = await getSavedUser();
        if (user != null) {
          user['balance'] = data['newBalance'];
          // 'purchasedAnimes' ni serverdan kelganiga almashtirish yaxshiroq,
          // lekin hozircha qo'shib qo'yamiz
          if (user['purchasedAnimes'] == null) user['purchasedAnimes'] = [];
          (user['purchasedAnimes'] as List).add(animeId);
          await saveUser(user);
        }
      }
      return data;
    } catch (e) {
      return {'ok': false, 'detail': e.toString()};
    }
  }

  // --- ANIMES ---
  static Future<List<dynamic>> getAnimes() async {
    if (_offlineMode) return []; // Biz endi 'in_memory_datasource' ishlatyapmiz
    try {
      final r = await http
          .get(Uri.parse('$baseUrl/animes'))
          .timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) {
        final data = jsonDecode(r.body);
        return data['animes'] ?? [];
      }
    } catch (_) {}
    return [];
  }

  static Future<Map<String, dynamic>?> getAnimeById(String id) async {
    try {
      final r = await http
          .get(Uri.parse('$baseUrl/anime/$id'))
          .timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) {
        final data = jsonDecode(r.body);
        return data['anime'];
      }
    } catch (_) {}
    return null;
  }

  // ⭐️⭐️⭐️ QAYTARILGAN FUNKSIYALAR ⭐️⭐️⭐️

  static Future<Map<String, dynamic>?> addAnime(
      Map<String, dynamic> data) async {
    if (_offlineMode) {
      data['id'] = DateTime.now().millisecondsSinceEpoch.toString();
      return data;
    }
    final token = await getToken();
    if (token == null) return null;
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/anime'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token'
        },
        body: jsonEncode(data),
      );
      if (res.statusCode == 201) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<bool> deleteAnime(String id) async {
    if (_offlineMode) return true;
    final token = await getToken();
    if (token == null) return false;
    try {
      final res = await http.delete(
        Uri.parse(
            '$baseUrl/anime/$id'), // Server.py da bu yo'q, lekin qo'shib qo'yamiz
        headers: {'Authorization': 'Bearer $token'},
      );
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> makeAdmin(
      String userId, Map<String, dynamic> data) async {
    if (_offlineMode) return true;
    final token = await getToken(); // Super Admin tokeni kerak
    if (token == null) return false;
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/add_admin'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token'
        },
        // server.py 'addedBy' ni ham kutadi, uni data ga qo'shish kerak
        body: jsonEncode({
          'userId': userId,
          'dubbingName': data['dub'] ?? 'Yangi Admin',
          'addedBy': '6526385624' // Super Admin ID
        }),
      );
      return res.statusCode == 201;
    } catch (e) {
      print("makeAdmin xato: $e");
      return false;
    }
  }

  static Future<bool> topUpBalance(String userId, double amount) async {
    if (_offlineMode) return true;
    final token = await getToken(); // Super Admin tokeni kerak
    if (token == null) return false;
    try {
      // server.py dagi endpoint
      final res = await http.post(
        Uri.parse('$baseUrl/admin/topup_user').replace(queryParameters: {
          'super_admin_id': '6526385624', // Super Admin ID
          'user_id': userId,
          'amount': amount.toString()
        }),
        headers: {'Authorization': 'Bearer $token'},
      );
      return res.statusCode == 200;
    } catch (e) {
      print("topUpBalance xato: $e");
      return false;
    }
  }
}
