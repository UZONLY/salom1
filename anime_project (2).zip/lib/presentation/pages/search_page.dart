// presentation/pages/search_page.dart
import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart'; // ⭐️ MUHIM: RemoteDataSource o'rniga shu import qilindi
import '../../domain/entities/anime.dart';
import 'anime_detail_page.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _searchController = TextEditingController();
  List<Anime> _allAnimes = [];
  List<Anime> _results = [];
  // ⭐️ O'ZGARISH: _loading olib tashlandi
  bool _hasSearched = false;

  @override
  void initState() {
    super.initState();
    _loadAnimes(); // ⭐️ O'ZGARISH: Bu endi sinxron (oddiy) funksiya
  }

  // ⭐️ O'ZGARISH: Funksiya endi 'Future' emas
  void _loadAnimes() {
    // ⭐️ O'ZGARISH: Ma'lumotlar serverdan emas, 'demoAnimes'dan olinadi
    _allAnimes = demoAnimes; 
    _results = demoAnimes;
  }

  void _onSearch(String query) {
    setState(() {
      _hasSearched = true;
      if (query.isEmpty) {
        _results = _allAnimes;
      } else {
        _results = _allAnimes
            .where((a) => a.title.toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(
        backgroundColor: const Color(0xFF252831),
        elevation: 0,
        title: Container(
          height: 46,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF2F323E),
            borderRadius: BorderRadius.circular(23),
            border: Border.all(color: const Color(0xFFF29824), width: 2),
          ),
          child: Row(
            children: [
              const Icon(Icons.search, color: Color(0xFFF29824), size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onChanged: _onSearch,
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                  decoration: const InputDecoration(
                    hintText: 'Anime nomi bo‘yicha qidiring...',
                    hintStyle: TextStyle(color: Colors.white54, fontSize: 14),
                    border: InputBorder.none,
                    isDense: true,
                  ),
                ),
              ),
              if (_searchController.text.isNotEmpty)
                GestureDetector(
                  onTap: () {
                    _searchController.clear();
                    _onSearch('');
                  },
                  child:
                      const Icon(Icons.clear, color: Colors.white54, size: 18),
                ),
            ],
          ),
        ),
        centerTitle: true,
      ),
      // ⭐️ O'ZGARISH: _loading tekshiruvi olib tashlandi
      body: _hasSearched && _results.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.search_off, size: 64, color: Colors.white38),
                  const SizedBox(height: 16),
                  const Text(
                    'Hech nima topilmadi',
                    style: TextStyle(color: Colors.white70, fontSize: 18),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '"${_searchController.text}"',
                    style:
                        const TextStyle(color: Color(0xFFF29824), fontSize: 16),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _results.length,
              itemBuilder: (ctx, i) {
                final anime = _results[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2F323E),
                    borderRadius: BorderRadius.circular(16),
                    border:
                        Border.all(color: const Color(0xFFF29824), width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(12),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        anime.thumbnailUrl,
                        width: 70,
                        height: 70,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: Colors.white10,
                          child: const Icon(Icons.broken_image,
                              color: Colors.white54),
                        ),
                      ),
                    ),
                    title: Text(
                      anime.title,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Row(
                      children: [
                        if (anime.price == 0)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.green,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Text('Bepul',
                                style: TextStyle(
                                    fontSize: 10, color: Colors.white)),
                          )
                        else
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF29824),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text('${anime.price.toStringAsFixed(0)} so‘m',
                                style: const TextStyle(
                                    fontSize: 10, color: Colors.black)),
                          ),
                        const SizedBox(width: 8),
                        Text(anime.dub,
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios,
                        color: Color(0xFFF29824), size: 16),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => AnimeDetailPage(anime: anime))),
                  ),
                );
              },
            ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}