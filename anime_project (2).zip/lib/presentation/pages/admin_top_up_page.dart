import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../widgets/common_widgets.dart';

class AdminTopUpPage extends StatefulWidget {
  const AdminTopUpPage({super.key});

  @override
  State<AdminTopUpPage> createState() => _AdminTopUpPageState();
}

class _AdminTopUpPageState extends State<AdminTopUpPage> {
  final userIdCtrl = TextEditingController();
  final amountCtrl = TextEditingController();

  Future<void> _topUp() async {
    final uid = userIdCtrl.text.trim();
    final amount = double.tryParse(amountCtrl.text) ?? 0;

    if (uid.isEmpty || amount <= 0) {
      showMessage(context, "To‘g‘ri kiriting");
      return;
    }

    final ok = await ApiService.topUpBalance(uid, amount);
    if (ok) {
      showMessage(context, "Balans to‘ldirildi!");
      Navigator.pop(context);
    } else {
      showMessage(context, "Xato!");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(
        title: const Text("Hisob to‘ldirish", style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF252831),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _field(userIdCtrl, "User ID"),
            _field(amountCtrl, "Summa", number: true),
            const SizedBox(height: 10),
            _btn("To‘ldirish", _topUp),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String t, {bool number = false}) {
    return TextField(
      controller: c,
      keyboardType: number ? TextInputType.number : TextInputType.text,
      style: const TextStyle(color: Colors.white),
      decoration: inputDecoration(t),
    );
  }

  Widget _btn(String t, Function() onTap) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFFF29824),
        minimumSize: const Size(double.infinity, 50),
      ),
      child: Text(t, style: const TextStyle(color: Colors.black)),
    );
  }
}
