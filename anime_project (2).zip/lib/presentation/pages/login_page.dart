// // // lib/presentation/pages/login_page.dart
// // import 'package:anime_project/data/datasources/in_memory_datasource.dart';
// // import 'package:flutter/material.dart';
// // import '../../domain/entities/user_profile.dart';
// // import '../../services/api_service.dart';
// // import '../pages/main_menu.dart';
// // import '../pages/register_page.dart';
// // import '../widgets/common_widgets.dart';

// // class LoginPage extends StatefulWidget {
// //   const LoginPage({super.key});
// //   @override State<LoginPage> createState() => _LoginPageState();
// // }

// // class _LoginPageState extends State<LoginPage> {
// //   final _emailCtrl = TextEditingController();
// //   final _passCtrl = TextEditingController();
// //   bool _loading = false;

// //   void _login() async {
// //     final email = _emailCtrl.text.trim();
// //     final pass = _passCtrl.text.trim();

// //     if (email.isEmpty || pass.isEmpty) {
// //       showMessage(context, 'Email va parol kiriting');
// //       return;
// //     }

// //     setState(() => _loading = true);
// //     final result = await ApiService.login(email, pass);
// //     setState(() => _loading = false);

// //     if (result != null) {
// //       final userData = result['user'];
// //       currentUser.value = UserProfile.fromJson(userData);

// //       showMessage(context, 'Muvaffaqiyatli kirdingiz!');
// //       Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainMenu()));
// //     } else {
// //       showMessage(context, 'Login yoki parol xato. Demo rejimda har qanday email/parol bilan kiring.');
// //     }
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       backgroundColor: const Color(0xFF252831),
// //       body: Center(
// //         child: SingleChildScrollView(
// //           padding: const EdgeInsets.all(24),
// //           child: Card(
// //             color: const Color(0xFF2F323E),
// //             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
// //             child: Padding(
// //               padding: const EdgeInsets.all(24),
// //               child: Column(
// //                 mainAxisSize: MainAxisSize.min,
// //                 children: [
// //                   const Text('Anime TV', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFFF29824))),
// //                   const SizedBox(height: 32),

// //                   TextField(
// //                     controller: _emailCtrl,
// //                     keyboardType: TextInputType.emailAddress,
// //                     style: const TextStyle(color: Colors.white),
// //                     decoration: InputDecoration(
// //                       labelText: 'Email',
// //                       labelStyle: const TextStyle(color: Colors.white70),
// //                       filled: true,
// //                       fillColor: const Color(0xFF3A3D4A),
// //                       border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
// //                     ),
// //                   ),
// //                   const SizedBox(height: 16),

// //                   TextField(
// //                     controller: _passCtrl,
// //                     obscureText: true,
// //                     style: const TextStyle(color: Colors.white),
// //                     decoration: InputDecoration(
// //                       labelText: 'Parol',
// //                       labelStyle: const TextStyle(color: Colors.white70),
// //                       filled: true,
// //                       fillColor: const Color(0xFF3A3D4A),
// //                       border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
// //                     ),
// //                   ),
// //                   const SizedBox(height: 24),

// //                   _loading
// //                       ? const CircularProgressIndicator(color: Color(0xFFF29824))
// //                       : SizedBox(
// //                           width: double.infinity,
// //                           child: ElevatedButton(
// //                             onPressed: _login,
// //                             style: ElevatedButton.styleFrom(
// //                               backgroundColor: const Color(0xFFF29824),
// //                               padding: const EdgeInsets.symmetric(vertical: 16),
// //                               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
// //                             ),
// //                             child: const Text('Kirish', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
// //                           ),
// //                         ),

// //                   const SizedBox(height: 16),
// //                   TextButton(
// //                     onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())),
// //                     child: const Text('Ro‘yxatdan o‘tish', style: TextStyle(color: Color(0xFFF29824))),
// //                   ),
// //                 ],
// //               ),
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }
// // lib/presentation/pages/login_page.dart
// // lib/presentation/pages/login_page.dart
// // lib/presentation/pages/login_page.dart
// // lib/presentation/pages/login_page.dart
// // lib/presentation/pages/login_page.dart
// import 'package:anime_project/data/datasources/in_memory_datasource.dart';
// import 'package:flutter/material.dart';
// import '../../domain/entities/user_profile.dart';
// import '../../services/api_service.dart';
// import '../pages/main_menu.dart';
// import '../pages/register_page.dart';
// import '../widgets/common_widgets.dart';

// class LoginPage extends StatefulWidget {
//   const LoginPage({super.key});
//   @override
//   State<LoginPage> createState() => _LoginPageState();
// }

// class _LoginPageState extends State<LoginPage> {
//   final _emailCtrl = TextEditingController();
//   final _passCtrl = TextEditingController();
//   bool _loading = false;

//   Future<void> _login() async {
//     final email = _emailCtrl.text.trim();
//     final pass = _passCtrl.text.trim();

//     if (email.isEmpty || pass.isEmpty) {
//       showMessage(context, 'Email va parol kiriting');
//       return;
//     }

//     setState(() => _loading = true);

//     try {
//       final result = await ApiService.login(email, pass);

//       // XATO yoki null
//       if (result == null || result['success'] != true || result['user'] == null) {
//         final msg = result?['message'] ?? 'Noma\'lum xato';
//         showMessage(context, msg);
//         return;
//       }

//       // MUVOFFAQIYAT
//       currentUser.value = UserProfile.fromJson(result['user']);
//       showMessage(context, 'Muvaffaqiyatli kirdingiz!');

//       if (!mounted) return;
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => const MainMenu()),
//       );
//     } catch (e) {
//       showMessage(context, 'Internet aloqasi yo‘q');
//     } finally {
//       // XAVFSIZ: mounted tekshiriladi
//       if (mounted) {
//         setState(() => _loading = false);
//       }
//     }
//   }

//   @override
//   void dispose() {
//     _emailCtrl.dispose();
//     _passCtrl.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFF252831),
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24),
//           child: Card(
//             color: const Color(0xFF2F323E),
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//             child: Padding(
//               padding: const EdgeInsets.all(24),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   const Text(
//                     'Anime TV',
//                     style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFFF29824)),
//                   ),
//                   const SizedBox(height: 32),

//                   TextField(
//                     controller: _emailCtrl,
//                     keyboardType: TextInputType.emailAddress,
//                     style: const TextStyle(color: Colors.white),
//                     decoration: inputDecoration('Email'),
//                   ),
//                   const SizedBox(height: 16),

//                   TextField(
//                     controller: _passCtrl,
//                     obscureText: true,
//                     style: const TextStyle(color: Colors.white),
//                     decoration: inputDecoration('Parol'),
//                   ),
//                   const SizedBox(height: 24),

//                   // LOADING YOKI TUGMA
//                   _loading
//                       ? const CircularProgressIndicator(color: Color(0xFFF29824))
//                       : ElevatedButton(
//                           onPressed: _login,
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: const Color(0xFFF29824),
//                             minimumSize: const Size(double.infinity, 50),
//                             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                           ),
//                           child: const Text('Kirish', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
//                         ),

//                   const SizedBox(height: 16),
//                   TextButton(
//                     onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())),
//                     child: const Text('Ro‘yxatdan o‘tish', style: TextStyle(color: Color(0xFFF29824))),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
// lib/presentation/pages/login_page.dart





// import 'package:anime_project/data/datasources/in_memory_datasource.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import '../../domain/entities/user_profile.dart';
// import '../../services/api_service.dart';
// import '../pages/main_menu.dart';
// import '../pages/register_page.dart';
// import '../widgets/common_widgets.dart';

// class LoginPage extends StatefulWidget {
//   const LoginPage({super.key});
//   @override
//   State<LoginPage> createState() => _LoginPageState();
// }

// class _LoginPageState extends State<LoginPage> {
//   final _emailCtrl = TextEditingController();
//   final _passCtrl = TextEditingController();
//   bool _loading = false;

//   @override
//   void initState() {
//     super.initState();
//     _loadSavedUser();
//   }

//   // Agar oldin saqlangan bo‘lsa avto-login
//   void _loadSavedUser() async {
//     final savedUser = await ApiService.getSavedUser();
//     if (savedUser != null) {
//       _emailCtrl.text = savedUser['email'] ?? '';
//       _passCtrl.text = ''; // Parol xavfsizlik uchun ko‘rsatilmaydi
//       _login(savedUser: savedUser);
//     }
//   }

//   // Oddiy login (backend orqali)
//   // Future<void> _login({Map<String, dynamic>? savedUser}) async {
//   //   final email = savedUser?['email'] ?? _emailCtrl.text.trim();
//   //   final pass = savedUser?['password'] ?? _passCtrl.text.trim();

//   //   if (email.isEmpty || pass.isEmpty) {
//   //     showMessage(context, 'Email va parol kiriting');
//   //     return;
//   //   }

//   //   setState(() => _loading = true);

//   //   try {
//   //     final result = await ApiService.login(email, pass);

//   //     if (result?['success'] == true && result?['user'] != null) {
//   //       var userMap = result!['user'];

//   //       // Backend parol qaytarmasa ham — biz uni saqlaymiz!
//   //       userMap['password'] = pass;

//   //       currentUser.value = UserProfile.fromJson(userMap);
//   //       await ApiService.saveUser(userMap);

//   //       showMessage(context, 'Muvaffaqiyatli kirdingiz!');

//   //       if (!mounted) return;
//   //       Navigator.pushReplacement(
//   //         context,
//   //         MaterialPageRoute(builder: (_) => const MainMenu()),
//   //       );
//   //     } else {
//   //       showMessage(context, result?['message'] ?? 'Login yoki parol xato');
//   //     }
//   //   } catch (e) {
//   //     showMessage(context, 'Internet aloqasi yo‘q yoki server ishlamayapti');
//   //   } finally {
//   //     if (mounted) setState(() => _loading = false);
//   //   }
//   // }
//   Future<void> _login({Map<String, dynamic>? savedUser}) async {
//   final email = savedUser?['email'] ?? _emailCtrl.text.trim();
//   final pass = savedUser?['password'] ?? _passCtrl.text.trim();

//   if (email.isEmpty || pass.isEmpty) {
//     showMessage(context, 'Email va parol kiriting');
//     return;
//   }

//   setState(() => _loading = true);

//   try {
//     final result = await ApiService.login(email, pass);

//     if (result?['success'] == true && result?['user'] != null) {
//       var userMap = result!['user'];

//       // Backend parol bermasa — qo‘shamiz
//       userMap['password'] = pass;

//       // USER yaratamiz
//       currentUser.value = UserProfile.fromJson(userMap);

//       // 🔥 ADMIN TEKSHIRUV — ENG MUHIMI
//       bool isAdmin = email == "shodiyor1@example.com" && pass == "shodiyor1!";

//       // 🔥 ADMIN SAQLAYMIZ
//       final prefs = await SharedPreferences.getInstance();
//       await prefs.setBool("isAdmin", isAdmin);

//       // USER SAQLANADI
//       await ApiService.saveUser(userMap);

//       showMessage(context, 'Muvaffaqiyatli kirdingiz!');

//       if (!mounted) return;
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => const MainMenu()),
//       );
//     } else {
//       showMessage(context, result?['message'] ?? 'Login yoki parol xato');
//     }
//   } catch (e) {
//     showMessage(context, 'Internet aloqasi yo‘q yoki server ishlamayapti');
//   } finally {
//     if (mounted) setState(() => _loading = false);
//   }
// }

//   // DEMO LOGIN — ENG MUHIMI! (Admin faqat shu orqali kiradi)
//   void _demoLogin({required bool isAdmin}) async {
//     setState(() => _loading = true);

//     final String email = isAdmin ? 'shodiyor1@example.com' : 'test@gmail.com';
//     final String password = isAdmin ? 'shodiyor1!' : 'test123';
//     final String name = isAdmin ? 'Shodiyor' : 'Test User';

//     try {
//       final result = await ApiService.login(email, password);

//       late UserProfile user;

//       if (result?['success'] == true && result?['user'] != null) {
//         user = UserProfile.fromJson(result!['user']);
//         if (user.password.isEmpty) {
//           user = UserProfile(
//             name: user.name,
//             email: user.email,
//             userId: user.userId,
//             password: password,
//             balance: user.balance,
//             purchasedAnimes: user.purchasedAnimes,
//             dub: user.dub,
//             hasFreeWatchUsed: user.hasFreeWatchUsed,
//             profileImagePath: user.profileImagePath,
//           );
//         }
//       } else {
//         // DEMO REJIM — HAR DOIM ISHLAYDI
//        user = UserProfile(
//   name: name,
//   email: email,
//   userId: isAdmin ? 'admin_001' : 'user_001',
//   password: password, // BU QATOR BO‘LISHI SHART!!!
//   balance: isAdmin ? 999999.0 : 100.0,
//   purchasedAnimes: isAdmin ? ['all'] : [],
//   dub: 'uz',
//   hasFreeWatchUsed: false,
//   profileImagePath: null,
// );
//       }

//       currentUser.value = user;
//       usersProfiles[email] = user;

//       showMessage(
//         context,
//         isAdmin ? 'Glavniy Admin kirdi!' : 'Oddiy foydalanuvchi kirdi!',
//         // color: isAdmin ? Colors.orange : Colors.green,
//       );

//       if (!mounted) return;
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => const MainMenu()),
//       );
//     } catch (e) {
//       // Offline demo rejim
//      final user = UserProfile(
//   name: name,
//   email: email,
//   userId: isAdmin ? 'admin_001' : 'user_001',
//   password: password, // BU YERDA HAM BO‘LSIN!
//   balance: isAdmin ? 999999.0 : 100.0,
//   purchasedAnimes: isAdmin ? ['all'] : [],
//   dub: 'uz',
//   hasFreeWatchUsed: false,
// );
//       currentUser.value = user;
//       usersProfiles[email] = user;

//       showMessage(context, 'DEMO: ${isAdmin ? 'Admin' : 'User'} kirdi (offline)');
//       if (!mounted) return;
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => const MainMenu()),
//       );
//     } finally {
//       if (mounted) setState(() => _loading = false);
//     }
//   }

//   @override
//   void dispose() {
//     _emailCtrl.dispose();
//     _passCtrl.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFF252831),
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24),
//           child: Card(
//             color: const Color(0xFF2F323E),
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//             elevation: 12,
//             child: Padding(
//               padding: const EdgeInsets.all(32),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   const Text(
//                     'Anime TV',
//                     style: TextStyle(
//                       fontSize: 34,
//                       fontWeight: FontWeight.bold,
//                       color: Color(0xFFF29824),
//                     ),
//                   ),
//                   const SizedBox(height: 40),

//                   TextField(
//                     controller: _emailCtrl,
//                     keyboardType: TextInputType.emailAddress,
//                     style: const TextStyle(color: Colors.white),
//                     decoration: inputDecoration('Email'),
//                   ),
//                   const SizedBox(height: 16),

//                   TextField(
//                     controller: _passCtrl,
//                     obscureText: true,
//                     style: const TextStyle(color: Colors.white),
//                     decoration: inputDecoration('Parol'),
//                   ),
//                   const SizedBox(height: 30),

//                   // Oddiy kirish tugmasi
//                   _loading
//                       ? const CircularProgressIndicator(color: Color(0xFFF29824))
//                       : ElevatedButton(
//                           onPressed: _login,
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: const Color(0xFFF29824),
//                             minimumSize: const Size(double.infinity, 56),
//                             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
//                           ),
//                           child: const Text(
//                             'Kirish',
//                             style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold),
//                           ),
//                         ),

//                   const SizedBox(height: 30),
//                   TextButton(
//                     onPressed: () => Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (_) => const RegisterPage()),
//                     ),
//                     child: const Text(
//                       'Ro‘yxatdan o‘tish',
//                       style: TextStyle(color: Color(0xFFF29824), fontSize: 16),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
import 'package:anime_project/data/datasources/in_memory_datasource.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../domain/entities/user_profile.dart';
import '../../services/api_service.dart';
import '../pages/main_menu.dart';
import '../pages/register_page.dart';
import '../widgets/common_widgets.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _tryAutoLogin();
  }

  // -------------------- AUT0 LOGIN --------------------
  Future<void> _tryAutoLogin() async {
    final saved = await ApiService.getSavedUser();

    if (saved == null) return;

    _emailCtrl.text = saved["email"] ?? "";
    String? password = saved["password"];

    if (password == null || password.isEmpty) return;

    _login(savedUser: saved);
  }

  // -------------------- LOGIN FUNKSIYA --------------------
  Future<void> _login({Map<String, dynamic>? savedUser}) async {
    final email = savedUser?["email"] ?? _emailCtrl.text.trim();
    final pass = savedUser?["password"] ?? _passCtrl.text.trim();

    if (email.isEmpty || pass.isEmpty) {
      showMessage(context, "Email va parolni kiriting");
      return;
    }

    setState(() => _loading = true);

    try {
      final result = await ApiService.login(email, pass);

      if (result?["success"] == true && result?["user"] != null) {
        var userData = result!["user"];

        // Parol backenddan kelmasa ham qo'shamiz
        userData["password"] = pass;

        currentUser.value = UserProfile.fromJson(userData);

        // ADMIN TEKSHIRUV
        bool isAdmin = email == "shodiyor1@example.com" && pass == "shodiyor1!";
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool("isAdmin", isAdmin);

        // SHARED PREFGA SAQLAYMIZ
        await ApiService.saveUser(userData);

        showMessage(context, "Muvaffaqiyatli kirdingiz!");

        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const MainMenu()),
        );
      } else {
        // API dan kelgan xato xabarni ko'rsatish
        final errorMessage = result?["message"] ?? "Login yoki parol noto'g'ri";
        showMessage(context, errorMessage);
      }
    } catch (e) {
      // Xatoni ko'rsatish
      showMessage(context, "Xato yuz berdi. Qayta urinib ko'ring");
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Card(
            color: const Color(0xFF2F323E),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            elevation: 12,
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                children: [
                  const Text(
                    'Anime TV',
                    style: TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFF29824),
                    ),
                  ),
                  const SizedBox(height: 40),

                  TextField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    style: const TextStyle(color: Colors.white),
                    decoration: inputDecoration('Email'),
                  ),
                  const SizedBox(height: 16),

                  TextField(
                    controller: _passCtrl,
                    obscureText: true,
                    style: const TextStyle(color: Colors.white),
                    decoration: inputDecoration('Parol'),
                  ),
                  const SizedBox(height: 30),

                  _loading
                      ? const CircularProgressIndicator(
                          color: Color(0xFFF29824),
                        )
                      : ElevatedButton(
                          onPressed: _login,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFF29824),
                            minimumSize: const Size(double.infinity, 56),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          child: const Text(
                            'Kirish',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),

                  const SizedBox(height: 30),
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const RegisterPage()),
                      );
                    },
                    child: const Text(
                      "Ro‘yxatdan o‘tish",
                      style: TextStyle(
                        color: Color(0xFFF29824),
                        fontSize: 16,
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
