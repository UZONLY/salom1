// lib/presentation/pages/home_page.dart
import 'package:flutter/material.dart';
import 'package:anime_project/domain/entities/anime.dart';
import 'anime_detail_page.dart';
import '../../data/datasources/in_memory_datasource.dart';
// lib/presentation/pages/home_page.dart
import 'dart:async'; // ⭐️ 1. BANNER UCHUN TIMER
import 'package:flutter/material.dart';
import 'package:anime_project/domain/entities/anime.dart';
import 'anime_detail_page.dart';
// ⭐️ 2. in_memory_datasource O'RNIGA API_SERVICE ISHLATAMIZ
import '../../services/api_service.dart'; // ⭐️ MUHIM: ApiService o'rniga shu import qilindi

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

// ⭐️⭐️⭐️ 'State' KLASSI TO'LIQ YANGILANDI ⭐️⭐️⭐️
class _HomePageState extends State<HomePage> {
  // 'demoAnimes' o'rniga endi 'Future'lardan foydalanamiz
  late Future<List<dynamic>> _bannersFuture;
  late Future<List<Anime>> _animesFuture;

  // Banner slider uchun
  PageController _bannerController = PageController();
  Timer? _bannerTimer;
  int _currentBannerPage = 0;

  @override
  void initState() {
    super.initState();
    // Datalarni serverdan yuklashni boshlaymiz
    _bannersFuture = ApiService.getBanners();
    _animesFuture = _loadAnimes();

    // Banner aylanishini boshlash
    _startBannerTimer();
  }

  // Anime yuklash funksiyasi
  Future<List<Anime>> _loadAnimes() async {
    final list = await ApiService.getAnimes();
    // 'id' yo'q animelarni olib tashlaymiz (muhim!)
    return list
        .map((e) => Anime.fromJson(e))
        .where((a) => a.id != null)
        .toList();
  }

  // Sahifani yangilash
  Future<void> _refreshData() async {
    setState(() {
      _bannersFuture = ApiService.getBanners();
      _animesFuture = _loadAnimes();
    });
  }

  // Banner timer funksiyalari
  void _startBannerTimer() {
    _bannerTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_bannerController.hasClients) {
        int nextPage = _currentBannerPage + 1;
        // Boshiga qaytish
        if (nextPage >= (_bannerController.page?.round() ?? 0) + 1) {
          _bannerController.animateToPage(
            0, // Boshiga qaytadi
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeOutCubic,
          );
        } else {
          _bannerController.animateToPage(
            nextPage,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeOutCubic,
          );
        }
      }
    });
  }

  @override
  void dispose() {
    _bannerController.dispose();
    _bannerTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1E1E26),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E26),
        title: const Text(
          'Anime TV', // Sarlavha
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 22),
        ),
        centerTitle: true,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: _refreshData, // Yangilash funksiyasi
          ),
        ],
      ),
      // Barcha sahifani RefreshIndicator bilan o'raymiz
      body: RefreshIndicator(
        onRefresh: _refreshData,
        color: const Color(0xFFF29824),
        backgroundColor: const Color(0xFF2F323E),
        child: Column(
          children: [
            // ⭐️ QISM 1: BANNER SLIDER
            _buildBannerSlider(),

            // ⭐️ QISM 2: ANIMELAR RO'YXATI
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
              child: Row(
                children: [
                  Text(
                    'Barcha Animelar',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _buildAnimeGrid(),
            ),
          ],
        ),
      ),
    );
  }

  // --- Banner Slider uchun yordamchi vidjet ---
  Widget _buildBannerSlider() {
    return FutureBuilder<List<dynamic>>(
      future: _bannersFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SizedBox(
            height: 200,
            child: Center(
                child: CircularProgressIndicator(color: Color(0xFFF29824))),
          );
        }
        if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
          return const SizedBox(
            height: 200,
            child: Center(
                child: Text('Bannerlar topilmadi',
                    style: TextStyle(color: Colors.white70))),
          );
        }

        final banners = snapshot.data!;

        return Container(
          height: 200,
          margin: const EdgeInsets.all(12),
          child: PageView.builder(
            controller: _bannerController,
            itemCount: banners.length,
            onPageChanged: (index) {
              setState(() {
                _currentBannerPage = index;
              });
            },
            itemBuilder: (context, index) {
              final banner = banners[index];
              return ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // Rasm
                    Image.network(
                      banner['imageUrl'],
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          const Center(child: Icon(Icons.broken_image)),
                    ),
                    // Qora gradient
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black.withOpacity(0.7)
                          ],
                          stops: const [0.5, 1.0],
                        ),
                      ),
                    ),
                    // Matn
                    Positioned(
                      bottom: 20,
                      left: 20,
                      child: Text(
                        banner['text'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(blurRadius: 10, color: Colors.black)
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  // --- Animelar ro'yxati uchun yordamchi vidjet ---
  Widget _buildAnimeGrid() {
    return FutureBuilder<List<Anime>>(
      future: _animesFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Color(0xFFF29824)));
        }

        if (snapshot.hasError) {
          return Center(
              child: Text('Yuklashda xato: ${snapshot.error}',
                  style: const TextStyle(color: Colors.red)));
        }

        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(
              child: Text('Hozircha animelar yo‘q',
                  style: TextStyle(color: Colors.white70)));
        }

        final animes = snapshot.data!;

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12.0),
          child: GridView.builder(
            itemCount: animes.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              childAspectRatio: 0.65,
            ),
            itemBuilder: (context, index) {
              final anime = animes[index];
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AnimeDetailPage(anime: anime),
                    ),
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 12,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.network(
                          anime.thumbnailUrl, // 'posterUrl' -> 'thumbnailUrl'
                          fit: BoxFit.cover,
                          loadingBuilder: (context, child, progress) {
                            if (progress == null) return child;
                            return Container(
                              color: const Color(0xFF2F323E),
                              child: const Center(
                                child: CircularProgressIndicator(
                                    color: Color(0xFFF29824), strokeWidth: 2.5),
                              ),
                            );
                          },
                          errorBuilder: (_, __, ___) {
                            return Container(
                              color: const Color(0xFF2F323E),
                              child: const Icon(Icons.broken_image,
                                  color: Colors.white54, size: 40),
                            );
                          },
                        ),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.transparent,
                                Colors.black.withOpacity(0.85)
                              ],
                              stops: const [0.6, 1.0],
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 16,
                          left: 12,
                          right: 12,
                          child: Text(
                            anime.title,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              shadows: [
                                Shadow(
                                    blurRadius: 12,
                                    color: Colors.black,
                                    offset: Offset(0, 3)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
