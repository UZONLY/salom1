// lib/presentation/pages/anime_list_page.dart
import 'package:anime_project/domain/entities/anime.dart';
import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart';
import '../pages/anime_detail_page.dart';

class AnimeListPage extends StatefulWidget {
  const AnimeListPage({super.key});

  @override
  State<AnimeListPage> createState() => _AnimeListPageState();
}

class _AnimeListPageState extends State<AnimeListPage> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = '';

  void _onAnimeTap(BuildContext context, Anime a) {
    if (currentUser.value == null) {
      _askLoginToWatch(context);
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => AnimeDetailPage(anime: a)),
      );
    }
  }

  void _askLoginToWatch(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF2F323E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Tomosha qilish uchun', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: const Text(
          'Tomosha qilish uchun ilovaga ro‘yxatdan o‘ting yoki tizimga kiring.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pushNamed(context, '/login');
            },
            child: const Text('Kirish', style: TextStyle(color: Color(0xFFF29824), fontWeight: FontWeight.bold)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pushNamed(context, '/register');
            },
            child: const Text('Ro‘yxatdan o‘tish', style: TextStyle(color: Color(0xFFF29824), fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // SARLAVHA
            const Text(
              'Barcha animelar ro\'yxati',
              style: TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),

            // GRID – KATTA RASM + NOMI
            Expanded(
              child: GridView.builder(
                itemCount: demoAnimes.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, // 2 ustun
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 0.68, // RASM KATTAROQ BO‘LSIN
                ),
                itemBuilder: (context, index) {
                  final a = demoAnimes[index];
                  return GestureDetector(
                    onTap: () => _onAnimeTap(context, a),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.4),
                            blurRadius: 12,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            // KATTA RASM
                            Image.network(
                              a.thumbnailUrl,
                              fit: BoxFit.cover,
                              loadingBuilder: (context, child, loadingProgress) {
                                if (loadingProgress == null) return child;
                                return Container(
                                  color: const Color(0xFF2F323E),
                                  child: const Center(
                                    child: CircularProgressIndicator(
                                      color: Color(0xFFF29824),
                                      strokeWidth: 2.5,
                                    ),
                                  ),
                                );
                              },
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  color: const Color(0xFF2F323E),
                                  child: const Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.broken_image, color: Colors.white54, size: 40),
                                      SizedBox(height: 8),
                                      Text('Rasm yo‘q', style: TextStyle(color: Colors.white54, fontSize: 12)),
                                    ],
                                  ),
                                );
                              },
                            ),

                            // QORA GRADIENT – faqat pastki qismida
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Colors.transparent,
                                    Colors.black.withOpacity(0.9),
                                  ],
                                  stops: const [0.55, 1.0],
                                ),
                              ),
                            ),

                            // NOMI – pastda, katta, o‘rtada, soya bilan
                            Positioned(
                              bottom: 16,
                              left: 14,
                              right: 14,
                              child: Text(
                                a.title,
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  height: 1.2,
                                  shadows: [
                                    Shadow(
                                      blurRadius: 12,
                                      color: Colors.black,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}