// lib/presentation/pages/admin_panel_page.dart
// ⭐️⭐️⭐️ TO'LIQ TO'G'RILANGAN KOD ⭐️⭐️⭐️

import 'package:anime_project/presentation/pages/admin_add_anime_page.dart'; // Anime qo'shish
import 'package:anime_project/presentation/pages/manage_reklama_page.dart';
import 'package:anime_project/presentation/pages/super_admin_page.dart';
import 'package:anime_project/presentation/pages/admin_list_page.dart'; // Adminlar ro'yxati
import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart';

class AdminPanelPage extends StatefulWidget {
  const AdminPanelPage({super.key});

  @override
  State<AdminPanelPage> createState() => _AdminPanelPageState();
}

class _AdminPanelPageState extends State<AdminPanelPage> {
  int _selectedIndex = 0;

  late final List<Widget> _pages;
  late final List<BottomNavigationBarItem> _navItems;

  @override
  void initState() {
    super.initState();
    // Biz 'api_service' dagi demo rejimga (yoki serverdagi super admin ID) ga tayanib tekshiramiz
    final isSuperAdmin = currentUser.value?.email == 'shodiyor1@example.com';

    _pages = [
      _buildDashboard(),
      const AdminAddAnimePage(),
      const ManageReklamaPage(),
      const AdminListPage(),
      if (isSuperAdmin) const SuperAdminPage(),
    ];

    _navItems = [
      const BottomNavigationBarItem(
          icon: Icon(Icons.dashboard), label: 'Dashboard'),
      const BottomNavigationBarItem(
          icon: Icon(Icons.movie_creation), label: 'Anime Qo‘shish'),
      const BottomNavigationBarItem(
          icon: Icon(Icons.campaign), label: 'Reklama'),
      BottomNavigationBarItem(
          icon: Icon(Icons.shield), // ⭐️ XATO ('shield_person') TUZATILDI
          label: 'Adminlar'),
      if (isSuperAdmin)
        const BottomNavigationBarItem(
            icon: Icon(Icons.security, color: Colors.red),
            label: 'Super Admin'),
    ];
  }

  // Dashboard (Statistika) vidjeti
  Widget _buildDashboard() {
    // Bu qism lokal 'in_memory_datasource' dan ma'lumot oladi.
    // Haqiqiy server uchun backenddan statistika (server.py /stats) olish kerak bo'ladi.
    final totalAnimes = demoAnimes.length;
    final freeAnimes = demoAnimes.where((a) => a.price == 0).length;
    final paidAnimes = totalAnimes - freeAnimes;
    final totalUsers = usersProfiles.length;
    final totalIncome = demoAnimes.fold<double>(
        0, (sum, a) => sum + (a.price * a.purchaseTimestamps.length));
    final totalViews =
        demoAnimes.fold<int>(0, (sum, a) => sum + a.viewTimestamps.length);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Admin Paneli',
            style: TextStyle(
                color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'Xush kelibsiz, ${currentUser.value?.email}',
            style: const TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 24),
          _statCard(
              'Jami animelar (Lokal)', totalAnimes.toString(), Icons.movie),
          _statCard('Jami foydalanuvchilar (Lokal)', totalUsers.toString(),
              Icons.person),
          _statCard('Jami daromad (Lokal)',
              '${totalIncome.toStringAsFixed(0)} so‘m', Icons.trending_up),
          _statCard('Ko‘rishlar soni (Lokal)', totalViews.toString(),
              Icons.remove_red_eye),
        ],
      ),
    );
  }

  // Statistika uchun yordamchi kartochka
  Widget _statCard(String title, String value, IconData icon) {
    return Card(
      color: const Color(0xFF2F323E),
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFFF29824)),
        title: Text(title,
            style: const TextStyle(color: Colors.white70, fontSize: 14)),
        trailing: Text(
          value,
          style: const TextStyle(
              color: Color(0xFFF29824),
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF2F323E),
        selectedItemColor: const Color(0xFFF29824),
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (i) => setState(() => _selectedIndex = i),
        items: _navItems,
      ),
    );
  }
}
