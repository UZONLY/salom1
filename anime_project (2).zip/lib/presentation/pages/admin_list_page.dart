// lib/presentation/pages/admin_list_page.dart
// ⭐️⭐️⭐️ BU YANGI FAYL ⭐️⭐️⭐️

import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart';

class AdminListPage extends StatelessWidget {
  const AdminListPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Biz hozircha faqat lokal 'in_memory'dagi adminlarni ko'rsatamiz
    // 'usersProfiles'dagi barcha foydalanuvchilarni olamiz
    final allUsers = usersProfiles.values.toList();

    // Ulardan faqat adminlarini (isRealAdmin true bo'lganlarni) filtrlaymiz
    final admins = allUsers.where((user) => user.isRealAdmin).toList();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Adminlar Ro‘yxati',
            style: TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: admins.length,
              itemBuilder: (ctx, i) {
                final admin = admins[i];
                return Card(
                  color: const Color(0xFF2F323E),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.redAccent,
                      child: Text(admin.name[0].toUpperCase()),
                    ),
                    title: Text(admin.name,
                        style: const TextStyle(color: Colors.white)),
                    subtitle: Text(admin.email,
                        style: const TextStyle(color: Colors.white70)),
                    trailing:
                        const Icon(Icons.verified_user, color: Colors.green),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
