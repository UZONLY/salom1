import 'package:shared_preferences/shared_preferences.dart';

class SharedService {
  static Future<void> saveUser(String email, bool isAdmin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString("userEmail", email);
    await prefs.setBool("isAdmin", isAdmin);
    await prefs.setBool("isLogged", true);
  }

  static Future<Map<String, dynamic>> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      "email": prefs.getString("userEmail"),
      "isAdmin": prefs.getBool("isAdmin") ?? false,
      "isLogged": prefs.getBool("isLogged") ?? false,
    };
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
