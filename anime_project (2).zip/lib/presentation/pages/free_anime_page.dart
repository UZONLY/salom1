// import 'package:flutter/material.dart';
// import '../../data/datasources/in_memory_datasource.dart';
// import 'anime_detail_page.dart';

// class FreeAnimePage extends StatefulWidget {
//   const FreeAnimePage({super.key});

//   @override
//   State<FreeAnimePage> createState() => _FreeAnimePageState();
// }

// class _FreeAnimePageState extends State<FreeAnimePage> {
//   final TextEditingController searchCtrl = TextEditingController();
//   String searchQuery = '';

//   @override
//   void initState() {
//     super.initState();
//     searchCtrl.addListener(() {
//       setState(() => searchQuery = searchCtrl.text.toLowerCase());
//     });
//   }

//   @override
//   void dispose() {
//     searchCtrl.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final freeAnimes = demoAnimes.where((anime) => anime.price == 0).toList();
//     final filteredAnimes = freeAnimes.where((anime) =>
//         anime.title.toLowerCase().contains(searchQuery) ||
//         anime.genre.toLowerCase().contains(searchQuery)).toList();

//     return Scaffold(
//       backgroundColor: const Color(0xFF252831),
//       appBar: AppBar(
//         backgroundColor: const Color(0xFF252831),
//         title: const Text('Tekin animelar', style: TextStyle(color: Colors.white)),
//         centerTitle: true,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.white),
//           onPressed: () => Navigator.maybePop(context),
//         ),
//       ),
//       body: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: TextField(
//               controller: searchCtrl,
//               style: const TextStyle(color: Colors.white),
//               decoration: const InputDecoration(
//                 hintText: 'Anime yoki janr bo‘yicha qidiring',
//                 hintStyle: TextStyle(color: Colors.white54),
//                 prefixIcon: Icon(Icons.search, color: Colors.white),
//                 filled: true,
//                 fillColor: Color(0xFF2F323E),
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.all(Radius.circular(8)),
//                   borderSide: BorderSide(color: Color(0xFFF29824)),
//                 ),
//               ),
//             ),
//           ),
//           Expanded(
//             child: ListView.builder(
//               padding: const EdgeInsets.all(16.0),
//               itemCount: filteredAnimes.length,
//               itemBuilder: (context, index) {
//                 final anime = filteredAnimes[index];
//                 return GestureDetector(
//                   onTap: () => Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => AnimeDetailPage(anime: anime),
//                     ),
//                   ),
//                   child: Container(
//                     margin: const EdgeInsets.only(bottom: 16),
//                     padding: const EdgeInsets.all(8),
//                     decoration: BoxDecoration(
//                       color: const Color(0xFF2F323E),
//                       borderRadius: BorderRadius.circular(8),
//                       border: Border.all(color: const Color(0xFFF29824)),
//                     ),
//                     child: Row(
//                       children: [
//                         Image.network(anime.thumbnailUrl, width: 100, height: 100, fit: BoxFit.cover),
//                         const SizedBox(width: 16),
//                         Expanded(
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text(anime.title, style: const TextStyle(color: Colors.white, fontSize: 16)),
//                               Text(anime.genre, style: const TextStyle(color: Colors.white70)),
//                               Text('Tekin', style: const TextStyle(color: Colors.green)),
//                             ],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 );
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart';
import 'anime_detail_page.dart';
import 'login_page.dart';

class FreeAnimesPage extends StatelessWidget {
  const FreeAnimesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final freeAnimes = demoAnimes.where((a) => a.price == 0).toList();
    final isLoggedIn = currentUser.value != null;

    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(title: const Text('Tekin Animelar')),
      body: isLoggedIn
          ? ListView.builder(
              itemCount: freeAnimes.length,
              itemBuilder: (ctx, i) {
                final anime = freeAnimes[i];
                return ListTile(
                  leading: Image.network(anime.thumbnailUrl, width: 50, height: 50, fit: BoxFit.cover),
                  title: Text(anime.title, style: const TextStyle(color: Colors.white)),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AnimeDetailPage(anime: anime))),
                );
              },
            )
          : Center(
              child: ElevatedButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
                child: const Text('Ro‘yxatdan o‘ting'),
              ),
            ),
    );
  }
}