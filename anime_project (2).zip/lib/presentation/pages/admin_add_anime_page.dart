// import 'package:anime_project/domain/entities/user_profile.dart';
// import 'package:flutter/material.dart';
// import '../../data/datasources/in_memory_datasource.dart';
// import '../widgets/common_widgets.dart';

// class AdminAddAdminPage extends StatefulWidget {
//   const AdminAddAdminPage({super.key});
//   @override State<AdminAddAdminPage> createState() => _AdminAddAdminPageState();
// }

// class _AdminAddAdminPageState extends State<AdminAddAdminPage> {
//   final _formKey = GlobalKey<FormState>();
//   final _nameCtrl = TextEditingController();
//   final _dubCtrl = TextEditingController();
//   final _userIdCtrl = TextEditingController();

//   void _save() {
//     if (_formKey.currentState!.validate()) {
//       final name = _nameCtrl.text.trim();
//       final dub = _dubCtrl.text.trim();
//       final userId = _userIdCtrl.text.trim();

//       // Foydalanuvchi ID bo‘yicha topish
//       final userEntry = usersProfiles.entries.firstWhere(
//         (e) => e.value.userId == userId,
//         orElse: () => MapEntry('', UserProfile(
//           name: '',
//           email: '',
//           userId: '',
//           balance: 0,
//           purchasedAnimes: [],
//           isAdmin: false,
//           dub: '',
//           hasFreeWatchUsed: true,
//         )),
//       );

//       if (userEntry.key.isEmpty) {
//         showMessage(context, 'Foydalanuvchi ID topilmadi!');
//         return;
//       }

//       final user = userEntry.value;
//       final updatedUser = UserProfile(
//         name: name,
//         email: user.email,
//         userId: user.userId,
//         balance: user.balance,
//         purchasedAnimes: user.purchasedAnimes,
//         isAdmin: true,
//         dub: dub,
//         hasFreeWatchUsed: user.hasFreeWatchUsed,
//       );

//       // Yangi adminni saqlash
//       usersProfiles[user.email] = updatedUser;
//       if (currentUser.value?.userId == userId) {
//         currentUser.value = updatedUser;
//       }

//       showMessage(context, '$name admin sifatida qo‘shildi!');
//       Navigator.pop(context);
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFF252831),
//       appBar: AppBar(
//         backgroundColor: const Color(0xFF252831),
//         title: const Text('Admin qo‘shish', style: TextStyle(color: Colors.white)),
//         centerTitle: true,
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16),
//         child: Form(
//           key: _formKey,
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 // Admin Ismi
//                 TextFormField(
//                   controller: _nameCtrl,
//                   decoration: const InputDecoration(
//                     labelText: 'Admin Ismi',
//                     labelStyle: TextStyle(color: Colors.white70),
//                     filled: true,
//                     fillColor: Color(0xFF3A3D4A),
//                     border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.all(Radius.circular(12))),
//                   ),
//                   style: const TextStyle(color: Colors.white),
//                   validator: (v) => v!.isEmpty ? 'Ism kerak' : null,
//                 ),
//                 const SizedBox(height: 16),

//                 // Dub (studiya)
//                 TextFormField(
//                   controller: _dubCtrl,
//                   decoration: const InputDecoration(
//                     labelText: 'Dublyaj (studiya)',
//                     labelStyle: TextStyle(color: Colors.white70),
//                     filled: true,
//                     fillColor: Color(0xFF3A3D4A),
//                     border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.all(Radius.circular(12))),
//                   ),
//                   style: const TextStyle(color: Colors.white),
//                   validator: (v) => v!.isEmpty ? 'Dub kerak' : null,
//                 ),
//                 const SizedBox(height: 16),

//                 // Foydalanuvchi ID
//                 TextFormField(
//                   controller: _userIdCtrl,
//                   decoration: const InputDecoration(
//                     labelText: 'Foydalanuvchi ID',
//                     labelStyle: TextStyle(color: Colors.white70),
//                     filled: true,
//                     fillColor: Color(0xFF3A3D4A),
//                     border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.all(Radius.circular(12))),
//                   ),
//                   style: const TextStyle(color: Colors.white),
//                   validator: (v) => v!.isEmpty ? 'ID kerak' : null,
//                 ),
//                 const SizedBox(height: 24),

//                 // Saqlash tugmasi
//                 SizedBox(
//                   width: double.infinity,
//                   child: ElevatedButton(
//                     onPressed: _save,
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: const Color(0xFFF29824),
//                       padding: const EdgeInsets.symmetric(vertical: 16),
//                       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                     ),
//                     child: const Text(
//                       'Admin qo‘shish',
//                       style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
// presentation/pages/admin_add_anime_page.dart
import 'package:anime_project/data/datasources/in_memory_datasource.dart';
import 'package:flutter/material.dart';
import '../../domain/entities/anime.dart';
import '../../domain/entities/user_profile.dart';
import '../../infrastructure/tools/url_converter.dart';
import '../widgets/common_widgets.dart';
// ... (boshqa importlar)
import '../../domain/entities/user_profile.dart';
import '../../infrastructure/tools/url_converter.dart';
import '../widgets/common_widgets.dart';
import '../../services/api_service.dart'; // ⭐️ 1. SHU IMPORTNI QO'SHING

class AdminAddAnimePage extends StatefulWidget {
  const AdminAddAnimePage({super.key});
  @override
  State<AdminAddAnimePage> createState() => _AdminAddAnimePageState();
}

class _AdminAddAnimePageState extends State<AdminAddAnimePage> {
  final _formKey = GlobalKey<FormState>();
  final _ctrl = {
    'title': TextEditingController(),
    'genre': TextEditingController(),
    'desc': TextEditingController(),
    'dub': TextEditingController(),
    'thumb': TextEditingController(),
    'banner': TextEditingController(),
    'episode': TextEditingController(),
  };
  double _price = 2900;
  bool _isBanner = false;
  final List<String> _episodes = [];

  @override
  void dispose() {
    _ctrl.values.forEach((c) => c.dispose());
    super.dispose();
  }

  void _addEpisode() {
    final url = _ctrl['episode']!.text.trim();
    if (url.isEmpty) return;
    if (!url.startsWith('https://drive.google.com/')) {
      showMessage(context, 'Faqat Google Drive URL');
      return;
    }
    setState(() {
      _episodes.add(url);
      _ctrl['episode']!.clear();
    });
  }

  // ⭐️⭐️⭐️ YANGILANGAN FUNKSIYA ⭐️⭐️⭐️
  void _saveAnime() async {
    if (!_formKey.currentState!.validate()) return;
    if (_episodes.isEmpty) {
      showMessage(context, 'Kamida 1 ta video qo‘shing');
      return;
    }

    final currentUserProfile = currentUser.value;
    if (currentUserProfile == null) {
      showMessage(context, 'Admin profili topilmadi. Qayta kiring.');
      return;
    }

    // 1. Backend 'AnimeCreate' modeli uchun Map tayyorlaymiz
    final Map<String, dynamic> animeData = {
      'title': _ctrl['title']!.text.trim(),
      'genre': _ctrl['genre']!.text.trim(),
      'desc': _ctrl['desc']!.text.trim(),
      'price': _price,
      'posterUrl': convertGoogleDriveUrl(_ctrl['thumb']!.text.trim()),
      'addedBy': currentUserProfile.userId,
      // 'dubbingName' server o'zi 'addedBy' orqali topadi
    };

    // 2. API orqali serverga yuboramiz
    final result = await ApiService.addAnime(animeData);

    if (result != null && result['ok'] == true) {
      // 3. Muvaffaqiyatli saqlansa, epizodlarni qo'shamiz
      // (Backendda epizodlar alohida qo'shiladi,
      // lekin hozircha biz faqat animeni o'zini qo'shamiz)

      // TODO: Epizodlarni 'ApiService.addEpisode' orqali qo'shish logikasi kerak

      showMessage(context, 'Anime muvaffaqiyatli serverga qo‘shildi!');

      // 4. Formni tozalash
      _formKey.currentState!.reset();
      _ctrl.values.forEach((c) => c.clear());
      _episodes.clear();
      setState(() => _price = 2900);
    } else {
      // Xato bo'lsa
      showMessage(context, 'Serverga saqlashda xato: ${result?['detail']}');
    }

    // 🔹 Agar reklama banneri tanlangan bo'lsa
    if (_isBanner) {
      // TODO: Backenddagi '/ad' endpoint'iga alohida so'rov yuborish kerak
      // Bu logikani keyin qo'shamiz. Hozircha faqat anime saqlash ishlasin.
      print("Reklama bannerini qo'shish uchun alohida API chaqiruvi kerak.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(
        backgroundColor: const Color(0xFF252831),
        title:
            const Text('Anime qo‘shish', style: TextStyle(color: Colors.white)),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _field(_ctrl['title']!, 'Anime nomi'),
            _field(_ctrl['genre']!, 'Janr'),
            _field(_ctrl['desc']!, 'Tavsif', maxLines: 3),
            _field(_ctrl['dub']!, 'Dub (JP, EN, UZ)'),
            DropdownButtonFormField<double>(
              value: _price,
              items: [0, 2900, 5900, 9900]
                  .map((p) => DropdownMenuItem(
                        value: p.toDouble(),
                        child: Text(
                          p == 0 ? 'Bepul' : '$p so‘m',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _price = v!),
              decoration: inputDecoration('Narx')
                  .copyWith(fillColor: const Color(0xFF2F323E)),
              dropdownColor: const Color(0xFF2F323E),
            ),
            _field(_ctrl['thumb']!, 'Rasm (Google Drive)'),
            _field(_ctrl['banner']!, 'Banner (Google Drive)'),
            _field(_ctrl['episode']!, 'Video URL'),
            _button('Video qo‘shish', _addEpisode),
            if (_episodes.isNotEmpty)
              ..._episodes.asMap().entries.map(
                    (e) => Card(
                      color: const Color(0xFF2F323E),
                      child: ListTile(
                        title: Text('Video ${e.key + 1}',
                            style: const TextStyle(color: Colors.white)),
                        subtitle: Text(e.value,
                            style: const TextStyle(
                                color: Colors.white54, fontSize: 10)),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () =>
                              setState(() => _episodes.removeAt(e.key)),
                        ),
                      ),
                    ),
                  ),
            Row(
              children: [
                Checkbox(
                    value: _isBanner,
                    onChanged: (v) => setState(() => _isBanner = v!),
                    activeColor: const Color(0xFFF29824)),
                const Text('Reklama banner (50,000 so‘m)',
                    style: TextStyle(color: Colors.white)),
              ],
            ),
            _button('Saqlash', _saveAnime),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String label,
          {int maxLines = 1, TextInputType? type}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: ctrl,
          maxLines: maxLines,
          keyboardType: type,
          decoration: inputDecoration(label)
              .copyWith(fillColor: const Color(0xFF2F323E)),
          style: const TextStyle(color: Colors.white),
          validator: (v) => v!.trim().isEmpty ? 'Majburiy' : null,
        ),
      );

  Widget _button(String text, VoidCallback onPressed) => Padding(
        padding: const EdgeInsets.only(top: 12),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFF29824),
            minimumSize: const Size(double.infinity, 50),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          child: Text(text,
              style: const TextStyle(
                  color: Colors.black, fontWeight: FontWeight.bold)),
        ),
      );
}
