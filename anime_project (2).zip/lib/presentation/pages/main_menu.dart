import 'package:anime_project/domain/entities/user_profile.dart';
import 'package:anime_project/presentation/pages/admin_add_admin_page.dart';
import 'package:anime_project/presentation/pages/admin_panel_page.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // YANGI
import '../../data/datasources/in_memory_datasource.dart';
import '../pages/anime_list_page.dart';
import '../pages/login_page.dart';
import '../pages/profile_page.dart';
import '../pages/search_page.dart';
import '../pages/free_anime_page.dart';

class MainMenu extends StatefulWidget {
  const MainMenu({super.key});
  @override
  State<MainMenu> createState() => _MainMenuState();
}

class _MainMenuState extends State<MainMenu> {
  int _selectedIndex = 0;

  bool isAdmin = false; // YANGI

  @override
  void initState() {
    super.initState();
    _loadAdminFlag(); // YANGI
  }

  // 🔥 SharedPreferences-dan adminlikni yuklash
  Future<void> _loadAdminFlag() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isAdmin = prefs.getBool("isAdmin") ?? false;
    });
  }

  List<Widget> _getPages(UserProfile? user) {
    final List<Widget> pages = [
      const AnimeListPage(),
      const SearchPage(),
      const FreeAnimesPage(),
      const ProfilePage(),
    ];

    if (isAdmin) {
      pages.add(const AdminPanelPage()); // Admin sahifasi
    }

    return pages;
  }

  List<BottomNavigationBarItem> _getNavItems(UserProfile? user) {
    final List<BottomNavigationBarItem> items = [
      const BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Bosh sahifa'),
      const BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Qidirish'),
      const BottomNavigationBarItem(icon: Icon(Icons.play_circle), label: 'Free Anime'),
      BottomNavigationBarItem(
        icon: const Icon(Icons.person),
        label: user == null ? 'Kirish' : 'Profil',
      ),
    ];

    // 🔥 ADMIN TUGMASINI KO‘RISH
    if (isAdmin) {
      items.add(
        const BottomNavigationBarItem(
          icon: Icon(Icons.admin_panel_settings, color: Colors.red),
          label: 'Admin Panel',
        ),
      );
    }

    return items;
  }

  void _onItemTapped(int index, UserProfile? user) {
    final pages = _getPages(user);
    if (index < pages.length) {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(
        backgroundColor: const Color(0xFF252831),
        title: const Text('Anime TV', style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      extendBody: true,
      body: ValueListenableBuilder<UserProfile?>(
        valueListenable: currentUser,
        builder: (context, user, _) {
          final pages = _getPages(user);

          if (_selectedIndex == 3 && user == null) {
            return const LoginPage();
          }

          if (_selectedIndex >= pages.length) {
            return const Center(
              child: Text('Sahifa topilmadi', style: TextStyle(color: Colors.white70)),
            );
          }

          return pages[_selectedIndex];
        },
      ),
      bottomNavigationBar: ValueListenableBuilder<UserProfile?>(
        valueListenable: currentUser,
        builder: (context, user, _) {
          final navItems = _getNavItems(user);

          return Padding(
            padding: const EdgeInsets.only(left: 24, right: 24, bottom: 18),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF2F323E).withOpacity(0.95),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: BottomNavigationBar(
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  selectedItemColor: const Color(0xFFF29824),
                  unselectedItemColor: Colors.grey,
                  selectedFontSize: 13,
                  unselectedFontSize: 11,
                  iconSize: 28,
                  type: BottomNavigationBarType.fixed,
                  currentIndex: _selectedIndex,
                  onTap: (index) => _onItemTapped(index, user),
                  items: navItems,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
