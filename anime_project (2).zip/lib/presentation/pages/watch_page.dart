// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:url_launcher/url_launcher.dart';

// class WatchPage extends StatefulWidget {
//   final String animeName;
//   final String episodeUrl;
//   final bool isPaid;
//   const WatchPage({super.key, required this.animeName, required this.episodeUrl, required this.isPaid});
//   @override
//   State<WatchPage> createState() => _WatchPageState();
// }

// class _WatchPageState extends State<WatchPage> {
//   bool _isFullScreen = false;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFF252831),
//       appBar: _isFullScreen
//           ? null
//           : AppBar(
//               backgroundColor: const Color(0xFF252831),
//               title: Text(widget.animeName, style: const TextStyle(color: Colors.white)),
//               centerTitle: true,
//               leading: IconButton(
//                 icon: const Icon(Icons.arrow_back, color: Colors.white),
//                 style: IconButton.styleFrom(
//                   backgroundColor: const Color(0xFF252831),
//                   shape: const CircleBorder(side: BorderSide(color: Colors.white)),
//                 ),
//                 onPressed: () => Navigator.maybePop(context),
//               ),
//             ),
//       body: OrientationBuilder(
//         builder: (context, orientation) {
//           _isFullScreen = orientation == Orientation.landscape;
//           return Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Expanded(
//                 child: Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       const Text(
//                         'Video yuklanmoqda...',
//                         style: TextStyle(color: Colors.white, fontSize: 18),
//                       ),
//                       const SizedBox(height: 16),
//                       Text(
//                         'URL: ${widget.episodeUrl}',
//                         style: const TextStyle(color: Colors.white70),
//                         textAlign: TextAlign.center,
//                       ),
//                       const SizedBox(height: 16),
//                       ElevatedButton(
//                         onPressed: () async {
//                           await launchUrl(Uri.parse(widget.episodeUrl));
//                         },
//                         style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//                         child: const Text('Tashqi pleerda ochish', style: TextStyle(color: Colors.black)),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               if (!_isFullScreen)
//                 ElevatedButton(
//                   onPressed: () {
//                     SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]);
//                   },
//                   style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//                   child: const Text('Katta Ekran', style: TextStyle(color: Colors.black)),
//                 ),
//             ],
//           );
//         },
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
//     super.dispose();
//   }
// }
import 'package:anime_project/domain/use_cases/watch_anime_use_case.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../data/datasources/in_memory_datasource.dart';
import '../../domain/entities/anime.dart';
import '../widgets/common_widgets.dart';

class WatchPage extends StatefulWidget {
  final Anime anime;
  final int initialEpisode;

  const WatchPage({super.key, required this.anime, this.initialEpisode = 0});

  @override
  State<WatchPage> createState() => _WatchPageState();
}

class _WatchPageState extends State<WatchPage> {
  int _currentEpisode = 0;

  //...
  @override
  void initState() {
    super.initState();
    _currentEpisode = widget.initialEpisode;
    
    // ⭐️⭐️⭐️ TUZATISH: Chaquv kechiktirildi ⭐️⭐️⭐️
    // Bu kod '_playEpisode' ni sahifa chizilib bo'lgandan keyin ishga tushiradi.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) { // Sahifa hali ham mavjudligini tekshirish
        _playEpisode(_currentEpisode);
      }
    });
  }
//...

  void _playEpisode(int episodeIndex) async {
    final message = tryWatch(context, widget.anime, currentUser.value);
    if (message != null) {
      showMessage(context, message);
      return;
    }

    final url = Uri.parse(widget.anime.episodeUrls[episodeIndex]);
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
      widget.anime.viewTimestamps.add(DateTime.now());
    } else {
      showMessage(context, 'Video ochilmadi');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isPurchased = currentUser.value?.purchasedAnimes.contains(widget.anime.title) ?? false;
    final isFree = widget.anime.price == 0;

    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(
        backgroundColor: const Color(0xFF252831),
        title: Text(widget.anime.title, style: const TextStyle(color: Colors.white)),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          style: IconButton.styleFrom(
            backgroundColor: const Color(0xFF252831),
            shape: const CircleBorder(side: BorderSide(color: Colors.white)),
          ),
          onPressed: () => Navigator.maybePop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 180,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFF29824)),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  widget.anime.thumbnailUrl,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) return child;
                    return const Center(child: CircularProgressIndicator(color: Color(0xFFF29824)));
                  },
                  errorBuilder: (context, error, stackTrace) => const Center(child: Text('Rasm yo\'q', style: TextStyle(color: Colors.white70))),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              widget.anime.title,
              style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Janr: ${widget.anime.genre}', style: const TextStyle(color: Colors.white70)),
            Text('Dublyaj: ${widget.anime.dub}', style: const TextStyle(color: Colors.white70)),
            Text('Tasnif: ${widget.anime.desc}', style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 12),
            Text(
              isFree ? 'Tekin' : 'Narx: ${widget.anime.price.toStringAsFixed(0)} so‘m',
              style: TextStyle(color: isFree ? Colors.green : Colors.white, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            const Text('Qismlar', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: widget.anime.episodeUrls.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text('Qism ${index + 1}', style: const TextStyle(color: Colors.white)),
                  trailing: (isPurchased || isFree)
                      ? IconButton(
                          icon: const Icon(Icons.play_arrow, color: Color(0xFFF29824)),
                          onPressed: () {
                            setState(() => _currentEpisode = index);
                            _playEpisode(index);
                          },
                        )
                      : null,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
