// import 'package:anime_project/domain/entities/user_profile.dart';
// import 'package:anime_project/presentation/pages/admin_panel_page.dart';
// import 'package:anime_project/presentation/pages/login_page.dart';
// import 'package:anoject/presentation/pages/register_page.dart';
// import 'package:flutter/material.dart';
// import 'package:url_launcher/url_launcher.dart';
// import '../../data/datasources/in_memory_datasource.dart';
// import '../widgets/common_widgets.dart';

// class ProfilePage extends StatefulWidget {
//   const ProfilePage({super.key});
//   @override
//   State<ProfilePage> createState() => _ProfilePageState();
// }

// class _ProfilePageState extends State<ProfilePage> {
//   final TextEditingController _amountCtrl = TextEditingController();

//   @override
//   void dispose() {
//     _amountCtrl.dispose();
//     super.dispose();
//   }

//   void _showTopUpDialog(BuildContext ctx, UserProfile user) {
//     _amountCtrl.text = '';
//     showDialog(
//       context: ctx,
//       builder: (dctx) => AlertDialog(
//         backgroundColor: const Color(0xFF2F323E),
//         title: const Text('Hisobni to\'ldirish', style: TextStyle(color: Colors.white)),
//         content: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             TextField(
//               controller: _amountCtrl,
//               keyboardType: TextInputType.number,
//               style: const TextStyle(color: Colors.white),
//               decoration: InputDecoration(
//                 labelText: 'Summa (so\'m)',
//                 labelStyle: const TextStyle(color: Colors.white70),
//                 filled: true,
//                 fillColor: const Color(0xFF1E2025),
//               ),
//             ),
//             const SizedBox(height: 16),
//             ElevatedButton(
//               onPressed: () async {
//                 await launchUrl(Uri.parse('https://t.me/prostashodiyor'));
//               },
//               style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//               child: const Text('Admin bilan', style: TextStyle(color: Colors.black)),
//             ),
//           ],
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(dctx),
//             child: const Text('Bekor', style: TextStyle(color: Colors.white70)),
//           ),
//           TextButton(
//             onPressed: () {
//               final val = double.tryParse(_amountCtrl.text) ?? 0.0;
//               if (val > 0) {
//                 user.balance += val;
//                 usersProfiles[user.email] = user;
//                 currentUser.value = user;
//                 Navigator.pop(dctx);
//                 showMessage(context, '$val so\'m hisobingizga qo\'shildi');
//               } else {
//                 showMessage(context, 'Iltimos to\'g\'ri summa kiriting');
//               }
//             },
//             child: const Text('To\'ldirish', style: TextStyle(color: Color(0xFFF29824))),
//           ),
//         ],
//       ),
//     );
//   }

//   void _openTelegram() async {
//     await launchUrl(Uri.parse('https://t.me/prostashodiyor'));
//   }

//   void _openAdminPanel(BuildContext context) {
//     Navigator.push(context, MaterialPageRoute(builder: (_) =>  AdminPanelPage()));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return ValueListenableBuilder<UserProfile?>(
//       valueListenable: currentUser,
//       builder: (context, user, _) {
//         if (user == null) {
//           return Scaffold(
//             backgroundColor: const Color(0xFF252831),
//             appBar: AppBar(
//               backgroundColor: const Color(0xFF252831),
//               title: const Text('Profil', style: TextStyle(color: Colors.white)),
//               centerTitle: true,
//               leading: IconButton(
//                 icon: const Icon(Icons.arrow_back, color: Colors.white),
//                 style: IconButton.styleFrom(
//                   backgroundColor: const Color(0xFF252831),
//                   shape: const CircleBorder(side: BorderSide(color: Colors.white)),
//                 ),
//                 onPressed: () => Navigator.maybePop(context),
//               ),
//             ),
//             body: Center(
//               child: SingleChildScrollView(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     const Text('Profilni ko\'rish uchun tizimga kiring', style: TextStyle(color: Colors.white70)),
//                     const SizedBox(height: 16),
//                     ElevatedButton(
//                       style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//                       onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
//                       child: const Text('Kirish', style: TextStyle(color: Colors.black)),
//                     ),
//                     const SizedBox(height: 8),
//                     TextButton(
//                       onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())),
//                       child: const Text('Ro\'yxatdan o\'tish', style: TextStyle(color: Color(0xFFF29824))),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         }
//         return Scaffold(
//           backgroundColor: const Color(0xFF252831),
//           appBar: AppBar(
//             backgroundColor: const Color(0xFF252831),
//             title: const Text('Profil', style: TextStyle(color: Colors.white)),
//             centerTitle: true,
//             leading: IconButton(
//               icon: const Icon(Icons.arrow_back, color: Colors.white),
//               style: IconButton.styleFrom(
//                 backgroundColor: const Color(0xFF252831),
//                 shape: const CircleBorder(side: BorderSide(color: Colors.white)),
//               ),
//               onPressed: () => Navigator.maybePop(context),
//             ),
//           ),
//           body: SingleChildScrollView(
//             padding: const EdgeInsets.all(16.0),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Container(
//                   width: 80,
//                   height: 80,
//                   decoration: BoxDecoration(
//                     color: const Color(0xFFF29824),
//                     shape: BoxShape.circle,
//                   ),
//                   child: Center(
//                     child: Text(
//                       user.name.isNotEmpty ? user.name[0].toUpperCase() : 'U',
//                       style: const TextStyle(color: Colors.black, fontSize: 24),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 12),
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text('Ism: ${user.name}', style: const TextStyle(color: Colors.white, fontSize: 16)),
//                     const SizedBox(height: 8),
//                     Text('Email: ${user.email}', style: const TextStyle(color: Colors.white, fontSize: 16)),
//                     const SizedBox(height: 8),
//                     Text('ID: ${user.userId}', style: const TextStyle(color: Colors.white, fontSize: 16)),
//                   ],
//                 ),
//                 const SizedBox(height: 14),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     const Text('Balans: ', style: TextStyle(color: Colors.white70)),
//                     Text('${user.balance.toStringAsFixed(0)} so\'m', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
//                 ElevatedButton(
//                   style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//                   onPressed: () => _showTopUpDialog(context, user),
//                   child: const Text('Pul to\'ldirish', style: TextStyle(color: Colors.black)),
//                 ),
//                 const SizedBox(height: 8),
//                 ElevatedButton(
//                   style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
//                   onPressed: () {
//                     currentUser.value = null;
//                     showMessage(context, 'Tizimdan chiqdingiz');
//                   },
//                   child: const Text('Chiqish', style: TextStyle(color: Colors.white)),
//                 ),
//                 const SizedBox(height: 16),
//                 if (user.isAdmin)
//                   ElevatedButton(
//                     style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//                     onPressed: () => _openAdminPanel(context),
//                     child: const Text('Admin Panel', style: TextStyle(color: Colors.black)),
//                   ),
//                 const SizedBox(height: 16),
//                 ElevatedButton(
//                   style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//                   onPressed: _openTelegram,
//                   child: const Text('Hamkorlik va Homiylik', style: TextStyle(color: Colors.black)),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
// import 'dart:io';
// import 'package:anime_project/domain/entities/user_profile.dart';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:url_launcher/url_launcher.dart';
// import '../../data/datasources/in_memory_datasource.dart';
// import '../pages/admin_panel_page.dart';
// import '../pages/login_page.dart';
// import '../pages/register_page.dart';
// import '../widgets/common_widgets.dart';

// class ProfilePage extends StatefulWidget {
//   const ProfilePage({super.key});

//   @override
//   State<ProfilePage> createState() => _ProfilePageState();
// }

// class _ProfilePageState extends State<ProfilePage> {
//   final TextEditingController _amountCtrl = TextEditingController();
//   File? _profileImage;

//   @override
//   void dispose() {
//     _amountCtrl.dispose();
//     super.dispose();
//   }

//   Future<void> _pickImage() async {
//     final picker = ImagePicker();
//     final pickedFile = await picker.pickImage(source: ImageSource.gallery);
//     if (pickedFile != null) {
//       setState(() {
//         _profileImage = File(pickedFile.path);
//       });
//       if (currentUser.value != null) {
//         currentUser.value!.profileImagePath = pickedFile.path;
//         usersProfiles[currentUser.value!.email] = currentUser.value!;
//       }
//     }
//   }

//   void _showTopUpDialog(BuildContext ctx, UserProfile user) {
//     _amountCtrl.text = '';
//     showDialog(
//       context: ctx,
//       builder: (dctx) => AlertDialog(
//         backgroundColor: const Color(0xFF2F323E),
//         title: const Text('Hisobni to\'ldirish', style: TextStyle(color: Colors.white)),
//         content: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             TextField(
//               controller: _amountCtrl,
//               keyboardType: TextInputType.number,
//               style: const TextStyle(color: Colors.white),
//               decoration: InputDecoration(
//                 labelText: 'Summa (so\'m)',
//                 labelStyle: const TextStyle(color: Colors.white70),
//                 filled: true,
//                 fillColor: const Color(0xFF1E2025),
//               ),
//             ),
//             const SizedBox(height: 16),
//             ElevatedButton(
//               onPressed: () async {
//                 await launchUrl(Uri.parse('https://t.me/prostashodiyor'));
//               },
//               style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//               child: const Text('Admin bilan', style: TextStyle(color: Colors.black)),
//             ),
//           ],
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(dctx),
//             child: const Text('Bekor', style: TextStyle(color: Colors.white70)),
//           ),
//           TextButton(
//             onPressed: () {
//               final val = double.tryParse(_amountCtrl.text) ?? 0.0;
//               if (val > 0) {
//                 user.balance += val;
//                 usersProfiles[user.email] = user;
//                 currentUser.value = user;
//                 Navigator.pop(dctx);
//                 showMessage(context, '$val so\'m hisobingizga qo\'shildi');
//               } else {
//                 showMessage(context, 'Iltimos to\'g\'ri summa kiriting');
//               }
//             },
//             child: const Text('To\'ldirish', style: TextStyle(color: Color(0xFFF29824))),
//           ),
//         ],
//       ),
//     );
//   }

//   void _openTelegram() async {
//     await launchUrl(Uri.parse('https://t.me/prostashodiyor'));
//   }

//   void _openAdminPanel(BuildContext context) {
//     Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPanelPage()));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return ValueListenableBuilder<UserProfile?>(
//       valueListenable: currentUser,
//       builder: (context, user, _) {
//         if (user == null) {
//           return Scaffold(
//             backgroundColor: const Color(0xFF252831),
//             appBar: AppBar(
//               backgroundColor: const Color(0xFF252831),
//               title: const Text('Profil', style: TextStyle(color: Colors.white)),
//               centerTitle: true,
//               leading: IconButton(
//                 icon: const Icon(Icons.arrow_back, color: Colors.white),
//                 style: IconButton.styleFrom(
//                   backgroundColor: const Color(0xFF252831),
//                   shape: const CircleBorder(side: BorderSide(color: Colors.white)),
//                 ),
//                 onPressed: () => Navigator.maybePop(context),
//               ),
//             ),
//             body: Center(
//               child: SingleChildScrollView(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     const Text('Profilni ko\'rish uchun tizimga kiring', style: TextStyle(color: Colors.white70)),
//                     const SizedBox(height: 16),
//                     ElevatedButton(
//                       style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
//                       onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
//                       child: const Text('Kirish', style: TextStyle(color: Colors.black)),
//                     ),
//                     const SizedBox(height: 8),
//                     TextButton(
//                       onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())),
//                       child: const Text('Ro\'yxatdan o\'tish', style: TextStyle(color: Color(0xFFF29824))),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         }
//         return Scaffold(
//           backgroundColor: const Color(0xFF252831),
//           appBar: AppBar(
//             backgroundColor: const Color(0xFF252831),
//             title: const Text('Profil', style: TextStyle(color: Colors.white)),
//             centerTitle: true,
//             leading: IconButton(
//               icon: const Icon(Icons.arrow_back, color: Colors.white),
//               style: IconButton.styleFrom(
//                 backgroundColor: const Color(0xFF252831),
//                 shape: const CircleBorder(side: BorderSide(color: Colors.white)),
//               ),
//               onPressed: () => Navigator.maybePop(context),
//             ),
//           ),
//           body: SingleChildScrollView(
//             padding: const EdgeInsets.all(16.0),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 const Text('Profil Haqida', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
//                 const SizedBox(height: 8),
//                 const Text('Bu sahifa orqali profilingizni boshqarishingiz mumkin.', style: TextStyle(color: Colors.white70)),
//                 const SizedBox(height: 24),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(vertical: 8.0),
//                   child: Container(
//                     padding: const EdgeInsets.all(8.0),
//                     decoration: BoxDecoration(
//                       color: const Color(0xFF2F323E),
//                       borderRadius: BorderRadius.circular(8),
//                       border: Border.all(color: const Color(0xFFF29824)),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         GestureDetector(
//                           onTap: _pickImage,
//                           child: CircleAvatar(
//                             radius: 40,
//                             backgroundImage: _profileImage != null
//                                 ? FileImage(_profileImage!)
//                                 : (user.profileImagePath != null && user.profileImagePath!.isNotEmpty
//                                     ? FileImage(File(user.profileImagePath!))
//                                     : null),
//                             child: _profileImage == null && (user.profileImagePath == null || user.profileImagePath!.isNotEmpty)
//                                 ? Text(
//                                     user.name.isNotEmpty ? user.name[0].toUpperCase() : 'U',
//                                     style: const TextStyle(color: Colors.black, fontSize: 24),
//                                   )
//                                 : null,
//                           ),
//                         ),
//                         const SizedBox(height: 12),
//                         Text('Ism: ${user.name}', style: const TextStyle(color: Colors.white, fontSize: 16)),
//                         const SizedBox(height: 8),
//                         Text('Email: ${user.email}', style: const TextStyle(color: Colors.white, fontSize: 16)),
//                         const SizedBox(height: 8),
//                         Text('ID: ${user.userId}', style: const TextStyle(color: Colors.white, fontSize: 16)),
//                       ],
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 12),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(vertical: 8.0),
//                   child: Container(
//                     padding: const EdgeInsets.all(8.0),
//                     decoration: BoxDecoration(
//                       color: const Color(0xFF2F323E),
//                       borderRadius: BorderRadius.circular(8),
//                       border: Border.all(color: const Color(0xFFF29824)),
//                     ),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         const Text('Balans: ', style: TextStyle(color: Colors.white70)),
//                         Text('${user.balance.toStringAsFixed(0)} so\'m', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
//                       ],
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 24),
//                 const Text('Amaliyotlar', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
//                 const SizedBox(height: 12),
//                 ElevatedButton(
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: const Color(0xFFF29824),
//                     minimumSize: const Size(double.infinity, 48),
//                   ),
//                   onPressed: () => _showTopUpDialog(context, user),
//                   child: const Text('Pul to\'ldirish', style: TextStyle(color: Colors.black)),
//                 ),
//                 const SizedBox(height: 12),
//                 if (user.isAdmin)
//                   ElevatedButton(
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: const Color(0xFFF29824),
//                       minimumSize: const Size(double.infinity, 48),
//                     ),
//                     onPressed: () => _openAdminPanel(context),
//                     child: const Text('Admin Panel', style: TextStyle(color: Colors.black)),
//                   ),
//                 const SizedBox(height: 12),
//                 ElevatedButton(
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: const Color(0xFFF29824),
//                     minimumSize: const Size(double.infinity, 48),
//                   ),
//                   onPressed: _openTelegram,
//                   child: const Text('Hamkorlik va Homiylik', style: TextStyle(color: Colors.black)),
//                 ),
//                 const SizedBox(height: 12),
//                 ElevatedButton(
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.redAccent,
//                     minimumSize: const Size(double.infinity, 48),
//                   ),
//                   onPressed: () {
//                     currentUser.value = null;
//                     Navigator.pushReplacement(
//                       context,
//                       MaterialPageRoute(builder: (context) => const LoginPage()),
//                     );
//                   },
//                   child: const Text('Chiqish', style: TextStyle(color: Colors.white)),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
import 'dart:io';
import 'package:anime_project/domain/entities/user_profile.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../data/datasources/in_memory_datasource.dart';
import '../pages/admin_panel_page.dart';
import '../pages/login_page.dart';
import '../widgets/common_widgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart'; // <-- Buni tekshiring/qo'shing
import '../../data/datasources/in_memory_datasource.dart';
import '../../services/api_service.dart'; // ⭐️ 1. YANGI IMPORT
import '../pages/admin_panel_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final TextEditingController _amountCtrl = TextEditingController();
  File? _tempImage;

  @override
  void dispose() {
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null && currentUser.value != null) {
      setState(() {
        _tempImage = File(pickedFile.path);
      });

      final updatedUser = UserProfile(
        name: currentUser.value!.name,
        email: currentUser.value!.email,
        userId: currentUser.value!.userId,
        password: currentUser.value!.password,
        balance: currentUser.value!.balance,
        purchasedAnimes: currentUser.value!.purchasedAnimes,
        dub: currentUser.value!.dub,
        hasFreeWatchUsed: currentUser.value!.hasFreeWatchUsed,
        profileImagePath: pickedFile.path,
      );

      usersProfiles[currentUser.value!.email] = updatedUser;
      currentUser.value = updatedUser;

      showMessage(context, 'Profil rasmi yangilandi!');
    }
  }

  // ⭐️⭐️⭐️ YANGILANGAN FUNKSIYA ⭐️⭐️⭐️
  void _showTopUpDialog(BuildContext ctx, UserProfile user) {
    _amountCtrl.clear();
    bool _isPaymentLoading = false;

    showDialog(
      context: ctx,
      builder: (context) {
        // 'StatefulBuilder' kerak, chunki biz Dialog ichidagi
        // "Yuklanmoqda..." holatini yangilashimiz kerak.
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: const Color(0xFF2F323E),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: const Text(
                'Hisobni to‘ldirish',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: _amountCtrl,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: 'Summa (so‘m)',
                      labelStyle: const TextStyle(color: Colors.white70),
                      filled: true,
                      fillColor: const Color(0xFF1E2025),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none),
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // Agar to'lov jarayoni ketsa, indikator ko'rsatamiz
                  if (_isPaymentLoading)
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: CircularProgressIndicator(color: Color(0xFFF29824)),
                      ),
                    )
                  else
                    // Aks holda, tugmani ko'rsatamiz
                    ElevatedButton.icon(
                      icon: const Icon(Icons.payment, color: Colors.black),
                      label: const Text('To‘lov qilish (TSPay)'),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFF29824)),
                      onPressed: () async {
                        final amount = double.tryParse(_amountCtrl.text) ?? 0;
                        if (amount < 1000) {
                          // Eng kam to'lov miqdori (misol uchun)
                          showMessage(ctx, 'Minimal to\'lov 1000 so\'m');
                          return;
                        }

                        // 1. Yuklanish holatini yoqamiz
                        setDialogState(() => _isPaymentLoading = true);

                        // 2. Backendga to'lov yaratish so'rovini yuboramiz
                        final result = await ApiService.createPayment(user.userId, amount);

                        // 3. Yuklanish holatini o'chiramiz
                        setDialogState(() => _isPaymentLoading = false);

                        if (result != null && result['ok'] == true) {
                          // 4. Agar muvaffaqiyatli bo'lsa, to'lov URLini olamiz
                          final paymentUrl = result['payment']?['paymentUrl'];
                          if (paymentUrl != null) {
                            // 5. To'lov oynasini ochamiz
                            final uri = Uri.parse(paymentUrl);
                            if (await canLaunchUrl(uri)) {
                              await launchUrl(uri, mode: LaunchMode.externalApplication);
                              Navigator.pop(context); // Dialog oynasini yopamiz
                              showMessage(ctx, 'To\'lov uchun oyna ochildi. To\'lovdan so\'ng hisobingizni yangilang.');
                            }
                          } else {
                            showMessage(ctx, 'To\'lov havolasini olishda xato');
                          }
                        } else {
                          // Backenddan xato kelsa
                          showMessage(ctx, result?['detail'] ?? 'To\'lov yaratishda xato');
                        }
                      },
                    ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Bekor', style: TextStyle(color: Colors.white70)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _openTelegram() async {
    await launchUrl(Uri.parse('https://t.me/prostashodiyor'));
  }

  void _openAdminPanel() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AdminPanelPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<UserProfile?>(
      valueListenable: currentUser,
      builder: (context, user, _) {
        if (user == null) {
          return Scaffold(
            backgroundColor: const Color(0xFF252831),
            appBar: AppBar(title: const Text('Profil'), backgroundColor: const Color(0xFF252831)),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Kirish kerak', style: TextStyle(color: Colors.white70, fontSize: 18)),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824)),
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
                    child: const Text('Kirish', style: TextStyle(color: Colors.black)),
                  ),
                ],
              ),
            ),
          );
        }

        final imagePath = _tempImage?.path ?? user.profileImagePath;
        final hasImage = imagePath != null && File(imagePath).existsSync();

        // Yangi: admin aniqlash (faqat email orqali)
        final bool isRealAdmin = user.email == 'shodiyor1@example.com';

        return Scaffold(
          backgroundColor: const Color(0xFF252831),
          appBar: AppBar(
            backgroundColor: const Color(0xFF252831),
            title: const Text('Profil', style: TextStyle(color: Colors.white)),
            centerTitle: true,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Profil', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 24),

                // Profil kartochkasi
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2F323E),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFF29824), width: 2),
                  ),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: _pickImage,
                        child: CircleAvatar(
                          radius: 44,
                          backgroundColor: const Color(0xFFF29824),
                          backgroundImage: hasImage ? FileImage(File(imagePath!)) : null,
                          child: !hasImage
                              ? Text(
                                  user.name.isNotEmpty ? user.name[0].toUpperCase() : 'U',
                                  style: const TextStyle(fontSize: 36, color: Colors.white),
                                )
                              : null,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Ism: ${user.name}', style: const TextStyle(color: Colors.white, fontSize: 18)),
                            Text('Email: ${user.email}', style: const TextStyle(color: Colors.white70)),
                            Text('ID: ${user.userId}', style: const TextStyle(color: Colors.white60, fontSize: 13)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Balans
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2F323E),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFF29824)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Balans', style: TextStyle(color: Colors.white70, fontSize: 18)),
                      Text(
                        '${user.balance.toStringAsFixed(0)} so‘m',
                        style: const TextStyle(color: Color(0xFFF29824), fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 32),
                const Text('Amallar', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),

                // Hisob to'ldirish
                ElevatedButton.icon(
                  icon: const Icon(Icons.account_balance_wallet),
                  label: const Text('Hisobni to‘ldirish'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF29824),
                    minimumSize: const Size(double.infinity, 56),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => _showTopUpDialog(context, user),
                ),
                const SizedBox(height: 12),

                // ADMIN PANEL BUTTON — faqat admin email uchun!
                if (isRealAdmin)
                  ElevatedButton.icon(
                    icon: const Icon(Icons.admin_panel_settings, color: Colors.white),
                    label: const Text('Admin Panel', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepOrange,
                      minimumSize: const Size(double.infinity, 60),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _openAdminPanel,
                  ),

                if (isRealAdmin) const SizedBox(height: 12),

                // Reklama
                ElevatedButton.icon(
                  icon: const Icon(Icons.telegram, color: Colors.white),
                  label: const Text('Reklama va hamkorlik'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0088CC),
                    minimumSize: const Size(double.infinity, 56),
                  ),
                  onPressed: _openTelegram,
                ),
                const SizedBox(height: 12),

                // Chiqish
                ElevatedButton.icon(
                  icon: const Icon(Icons.logout, color: Colors.white),
                  label: const Text('Chiqish'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    minimumSize: const Size(double.infinity, 56),
                  ),
                  onPressed: () {
                    currentUser.value = null;
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage()));
                  },
                ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        );
      },
    );
  }
}
