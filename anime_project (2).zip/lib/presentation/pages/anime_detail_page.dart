// presentation/pages/anime_detail_page.dart
// ⭐️⭐️⭐️ TO'LIQ TUZATILGAN FAYL ⭐️⭐️⭐️

import 'package:anime_project/domain/entities/anime.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

import '../../data/datasources/in_memory_datasource.dart';
import '../../services/api_service.dart';
import '../../infrastructure/tools/url_converter.dart';
import '../widgets/common_widgets.dart'; // ⭐️ 1. showMessage UCHUN IMPORT QO'SHILDI
import '../../domain/entities/user_profile.dart'; // ⭐️ 2. UserProfile UCHUN IMPORT QO'SHILDI

class AnimeDetailPage extends StatefulWidget {
  final Anime anime;
  const AnimeDetailPage({super.key, required this.anime});

  @override
  State<AnimeDetailPage> createState() => _AnimeDetailPageState();
}

class _AnimeDetailPageState extends State<AnimeDetailPage> {
  bool _isPurchased = false;
  bool _isLoading = false;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  late Anime _anime;

  @override
  void initState() {
    super.initState();
    _anime = widget.anime;
    _checkPurchaseStatus();
    _loadAnimeFromBackend();
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _loadAnimeFromBackend() async {
    try {
      final animeId = _anime.id; // ⭐️ 'id' ni null tekshirish uchun
      if (animeId != null) {
        final updated = await ApiService.getAnimeById(animeId);
        if (updated != null && mounted) {
          setState(() {
            _anime = Anime.fromJson(updated);
          });
        }
      }
    } catch (e) {
      print('Backenddan yuklashda xato: $e');
    }
  }

  void _checkPurchaseStatus() {
    final user = currentUser.value;
    if (user == null) return;
    setState(() {
      // ⭐️ MANTIQ TUZATILDI: Biz 'user_profile.dart' dagi 'purchasedAnimes' listini tekshiramiz
      // Bu list 'login' va 'purchaseAnime' da yangilanadi
      _isPurchased = user.purchasedAnimes.contains(_anime.id) ||
          user.purchasedAnimes
              .contains(_anime.title); // Eski mantiq bilan moslik
    });
  }

  // ⭐️ 3. 'async' QO'SHILDI, CHUNKI ICHIDA 'await' BOR
  Future<void> _buyAnime() async {
    final user = currentUser.value;
    if (user == null) {
      showMessage(context, 'Iltimos, tizimga kiring');
      return;
    }

    if (_anime.price == 0) {
      setState(() => _isPurchased = true);
      return;
    }

    setState(() => _isLoading = true);

    // ⭐️ 4. 'id' NULL BO'LSA XATOLIKNI USHLASH
    final animeId = _anime.id;
    if (animeId == null) {
      setState(() => _isLoading = false);
      showMessage(context, 'Anime ID topilmadi, xato!');
      return;
    }

    // ⭐️ 5. 'animeId' ENDI NULL EMASLIGI ANIQ
    final result = await ApiService.purchaseAnime(user.userId, animeId);

    setState(() => _isLoading = false);

    if (result != null && result['ok'] == true && result['purchased'] == true) {
      showMessage(context, 'Anime muvaffaqiyatli sotib olindi!');

      // ⭐️ 6. 'await' setState ICHIDAN TASHQARIGA CHIQARILDI
      final savedUser = await ApiService.getSavedUser();
      if (mounted) {
        setState(() {
          currentUser.value = UserProfile.fromJson(savedUser ?? {});
          _isPurchased = true;
        });
      }
    } else {
      if (result?['detail'] == 'insufficient_balance') {
        showMessage(
            context, 'Balansingiz yetarli emas! Avval hisobni to\'ldiring.');
      } else {
        showMessage(context, result?['detail'] ?? 'Sotib olishda xato');
      }
    }
  }

  // _showPaymentWebView (Click uchun) endi kerak emas, chunki u 7-qadamda olib tashlangan

  void _playEpisode(String url, int index) {
    final playableUrl = convertGoogleDriveUrl(url);

    _videoController = VideoPlayerController.networkUrl(Uri.parse(playableUrl));
    _chewieController = ChewieController(
      videoPlayerController: _videoController!,
      aspectRatio: 16 / 9,
      autoPlay: true,
      looping: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: const Color(0xFFF29824),
        handleColor: const Color(0xFFF29824),
        backgroundColor: Colors.grey,
        bufferedColor: Colors.white30,
      ),
      placeholder: const Center(
          child: CircularProgressIndicator(color: Color(0xFFF29824))),
    );

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: const EdgeInsets.all(0),
        child: Stack(
          children: [
            Chewie(controller: _chewieController!),
            Positioned(
              top: 40,
              right: 16,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 30),
                onPressed: () {
                  _chewieController?.pause();
                  Navigator.pop(ctx);
                },
              ),
            ),
          ],
        ),
      ),
    ).then((_) {
      _chewieController?.dispose();
      _videoController?.dispose();
    });
  }

  @override
  Widget build(BuildContext context) {
    _checkPurchaseStatus();

    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(
        backgroundColor: const Color(0xFF252831),
        title: Text(_anime.title,
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  _anime.thumbnailUrl,
                  width: double.infinity,
                  height: 220,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: Colors.white10,
                    child: const Icon(Icons.broken_image,
                        color: Colors.white54, size: 60),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                _anime.title,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _infoChip(Icons.category, _anime.genre, 'Janr'),
                  const SizedBox(width: 12),
                  _infoChip(Icons.mic, _anime.dub, 'Studiya'),
                ],
              ),
              const SizedBox(height: 16),
              const Text('Tavsif',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(
                _anime.desc.isEmpty ? 'Tavsif mavjud emas' : _anime.desc,
                style: const TextStyle(
                    color: Colors.white70, fontSize: 15, height: 1.6),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  const Text('Narx: ',
                      style: TextStyle(color: Colors.white, fontSize: 16)),
                  Text(
                    _anime.price == 0
                        ? 'Bepul'
                        : '${_anime.price.toStringAsFixed(0)} so‘m',
                    style: TextStyle(
                      color: _anime.price == 0
                          ? Colors.green
                          : const Color(0xFFF29824),
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Center(
                child: _isLoading
                    ? const CircularProgressIndicator(color: Color(0xFFF29824))
                    : SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _isPurchased
                                ? Colors.grey
                                : const Color(0xFFF29824),
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: _isPurchased ? null : _buyAnime,
                          child: Text(
                            _isPurchased
                                ? 'Sotib olingan'
                                : 'Sotib olish (Balansdan)',
                            style: const TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
              ),
              const SizedBox(height: 20),
              if ((_isPurchased || _anime.price == 0) &&
                  _anime.episodeUrls.isNotEmpty) ...[
                const Text('Epizodlar:',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                ..._anime.episodeUrls.asMap().entries.map((entry) {
                  final index = entry.key + 1;
                  final url = entry.value;
                  return Card(
                    color: const Color(0xFF2F323E),
                    margin: const EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: const Color(0xFFF29824),
                        child: Text('$index',
                            style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold)),
                      ),
                      title: Text('$index-qism',
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600)),
                      trailing: ElevatedButton.icon(
                        icon: const Icon(Icons.play_arrow,
                            color: Colors.black, size: 18),
                        label: const Text('Play',
                            style: TextStyle(color: Colors.black)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFF29824),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () => _playEpisode(url, index),
                      ),
                    ),
                  );
                }),
              ] else if (!_isPurchased && _anime.price > 0)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Video faqat sotib olingandan keyin ochiladi',
                      style: TextStyle(color: Colors.white70, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              const SizedBox(height: 24),
              Center(
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFFF29824), width: 2),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 40, vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30)),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Orqaga',
                      style: TextStyle(
                          color: Color(0xFFF29824),
                          fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoChip(IconData icon, String text, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF2F323E),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF29824), width: 1.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: const Color(0xFFF29824), size: 18),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(color: Colors.white70, fontSize: 10)),
              Text(text,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 13)),
            ],
          ),
        ],
      ),
    );
  }
}
