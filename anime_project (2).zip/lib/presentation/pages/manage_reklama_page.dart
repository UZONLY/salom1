// lib/presentation/pages/manage_reklama_page.dart
// ⭐️ BU FAYLNI QAYTA YARATING ⭐️

import 'package:anime_project/domain/entities/anime.dart';
import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart';

class ManageReklamaPage extends StatelessWidget {
  const ManageReklamaPage({super.key});

  void _approve(Anime anime, BuildContext context) {
    // Bu funksiya hozircha faqat lokal 'in_memory_datasource' uchun ishlaydi
    anime.advertiseBanner = true;
    banners.value = List.from(banners.value)..add(anime);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${anime.title} reklamasi tasdiqlandi!'),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pending = demoAnimes
        .where((a) => a.advertiseBanner == true && !banners.value.contains(a))
        .toList();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Reklama so‘rovlari',
            style: TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          pending.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32.0),
                    child: Text(
                      'Tasdiqlanmagan reklama so‘rovlari yo‘q',
                      style: TextStyle(color: Colors.white70, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : Expanded(
                  child: ListView.builder(
                    itemCount: pending.length,
                    itemBuilder: (ctx, i) {
                      final a = pending[i];
                      return Card(
                        color: const Color(0xFF2F323E),
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: Image.network(a.thumbnailUrl,
                              width: 60, height: 60, fit: BoxFit.cover),
                          title: Text(a.title,
                              style: const TextStyle(color: Colors.white)),
                          subtitle: const Text('Reklama uchun so‘rov',
                              style: TextStyle(color: Color(0xFFF29824))),
                          trailing: ElevatedButton(
                            onPressed: () => _approve(a, ctx),
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green),
                            child: const Text('Tasdiqlash'),
                          ),
                        ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }
}
