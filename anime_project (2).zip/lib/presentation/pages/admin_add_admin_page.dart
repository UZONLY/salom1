// presentation/pages/admin_add_admin_page.dart
import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../widgets/common_widgets.dart';

class AdminAddAdminPage extends StatefulWidget {
  const AdminAddAdminPage({super.key});
  @override State<AdminAddAdminPage> createState() => _AdminAddAdminPageState();
}

class _AdminAddAdminPageState extends State<AdminAddAdminPage> {
  final _nameCtrl = TextEditingController();
  final _dubCtrl = TextEditingController();
  final _userIdCtrl = TextEditingController();

  @override
  void dispose() {
    _nameCtrl.dispose();
    _dubCtrl.dispose();
    _userIdCtrl.dispose();
    super.dispose();
  }

  Future<void> _addAdmin() async {
    final name = _nameCtrl.text.trim();
    final dub = _dubCtrl.text.trim();
    final userId = _userIdCtrl.text.trim();
    if (name.isEmpty || dub.isEmpty || userId.isEmpty) {
      showMessage(context, 'Barcha maydonlar to‘ldirilishi kerak');
      return;
    }
    final success = await ApiService.makeAdmin(userId, {'name': name, 'dub': dub});
    if (success) {
      showMessage(context, '$name admin qo‘shildi');
      Navigator.pop(context);
    } else {
      showMessage(context, 'Xato. User ID noto‘g‘ri bo‘lishi mumkin.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(backgroundColor: const Color(0xFF252831), title: const Text('Admin qo‘shish', style: TextStyle(color: Colors.white))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _field(_nameCtrl, 'Ism'),
        _field(_dubCtrl, 'Dub (JP, EN)'),
        _field(_userIdCtrl, 'User ID'),
        _button('Qo‘shish', _addAdmin),
      ]),
    );
  }

  Widget _field(TextEditingController ctrl, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: ctrl,
          decoration: inputDecoration(label).copyWith(fillColor: const Color(0xFF2F323E)),
          style: const TextStyle(color: Colors.white),
        ),
      );

  Widget _button(String text, VoidCallback onPressed) => Padding(
        padding: const EdgeInsets.only(top: 12),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF29824), minimumSize: const Size(double.infinity, 50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
          child: Text(text, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        ),
      );
}