// import 'package:flutter/material.dart';
// import '../../data/datasources/do_register.dart';
// import '../pages/main_menu.dart';
// import '../widgets/common_widgets.dart';

// class RegisterPage extends StatefulWidget {
//   const RegisterPage({super.key});

//   @override
//   State<RegisterPage> createState() => _RegisterPageState();
// }

// class _RegisterPageState extends State<RegisterPage> {
//   final TextEditingController _nameCtrl = TextEditingController();
//   final TextEditingController _emailCtrl = TextEditingController();
//   final TextEditingController _passwordCtrl = TextEditingController();

//   void _register() {
//     final name = _nameCtrl.text.trim();
//     final email = _emailCtrl.text.trim();
//     final password = _passwordCtrl.text.trim();

//     final message = doRegister(name, email, password);
//     if (message != null) {
//       showMessage(context, message);
//       return;
//     }

//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(builder: (context) => const MainMenu()),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFF252831),
//       appBar: AppBar(
//         backgroundColor: const Color(0xFF252831),
//         title: const Text('Ro\'yxatdan o\'tish', style: TextStyle(color: Colors.white)),
//         centerTitle: true,
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             TextField(
//               controller: _nameCtrl,
//               style: const TextStyle(color: Colors.white),
//               decoration: inputDecoration('Ism'),
//             ),
//             const SizedBox(height: 12),
//             TextField(
//               controller: _emailCtrl,
//               style: const TextStyle(color: Colors.white),
//               decoration: inputDecoration('Email'),
//             ),
//             const SizedBox(height: 12),
//             TextField(
//               controller: _passwordCtrl,
//               style: const TextStyle(color: Colors.white),
//               obscureText: true,
//               decoration: inputDecoration('Parol'),
//             ),
//             const SizedBox(height: 16),
//             ElevatedButton(
//               onPressed: _register,
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: const Color(0xFFF29824),
//                 minimumSize: const Size(double.infinity, 48),
//               ),
//               child: const Text('Ro\'yxatdan o\'tish', style: TextStyle(color: Colors.black)),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
// presentation/pages/register_page.dart
// ⭐️⭐️⭐️ TO'LIQ YANGILANGAN FAYL ⭐️⭐️⭐️

import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../widgets/common_widgets.dart';
import 'login_page.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  // ⭐️ 1. Ism uchun controller qo'shildi
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _loading = false;

  @override
  void dispose() {
    // ⭐️ 2. 'dispose' ga qo'shildi
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  void _register() async {
    // ⭐️ 3. 'name' o'qilmoqda
    final name = _nameCtrl.text.trim();
    final email = _emailCtrl.text.trim();
    final pass = _passCtrl.text;
    final confirm = _confirmCtrl.text;

    if (pass != confirm) {
      showMessage(context, 'Parollar mos emas');
      return;
    }
    // ⭐️ 4. 'name' tekshiruvga qo'shildi
    if (name.isEmpty || email.isEmpty || pass.isEmpty) {
      showMessage(context, 'Barcha maydonlar to‘ldirilishi kerak');
      return;
    }
    
    // Backenddagi minimal parol uzunligiga moslash
    if (pass.length < 6) {
        showMessage(context, 'Parol kamida 6 belgidan iborat bo‘lishi kerak');
        return;
    }

    setState(() => _loading = true);
    
    // ⭐️ 5. 'name' ApiService ga yuborilmoqda
    final result = await ApiService.register(name, email, pass);
    setState(() => _loading = false);

    if (result != null && result['ok'] == true) {
      showMessage(context, 'Muvaffaqiyatli ro‘yxatdan o‘tdingiz! Kirish uchun login sahifasiga o‘ting.');
      if (mounted) {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => const LoginPage()));
      }
    } else {
      // Backenddan keladigan xatolarni ko'rsatish
      String message = 'Xato: Server bilan bog\'lanib bo\'lmadi';
      if (result?['detail'] == 'user_exists') {
        message = 'Bu email allaqachon ro‘yxatga olingan';
      } else if (result?['message'] != null) {
        message = result!['message'];
      }
      
      showMessage(context, message);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(
        backgroundColor: const Color(0xFF252831),
        title: const Text('Ro‘yxatdan o‘tish', style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Card(
            color: const Color(0xFF2F323E),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Anime TV',
                    style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFF29824)),
                  ),
                  const SizedBox(height: 32),

                  // ⭐️ 6. "Ism" maydoni qo'shildi
                  TextField(
                    controller: _nameCtrl,
                    keyboardType: TextInputType.name,
                    style: const TextStyle(color: Colors.white),
                    decoration: inputDecoration('Ism'), // common_widgets dan
                  ),
                  const SizedBox(height: 16),

                  TextField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    style: const TextStyle(color: Colors.white),
                    decoration: inputDecoration('Email'), // common_widgets dan
                  ),
                  const SizedBox(height: 16),
                  
                  TextField(
                    controller: _passCtrl,
                    obscureText: true,
                    style: const TextStyle(color: Colors.white),
                    decoration: inputDecoration('Parol (kamida 6 belgi)'), // common_widgets dan
                  ),
                  const SizedBox(height: 16),
                  
                  TextField(
                    controller: _confirmCtrl,
                    obscureText: true,
                    style: const TextStyle(color: Colors.white),
                    decoration: inputDecoration('Parolni tasdiqlash'), // common_widgets dan
                  ),
                  const SizedBox(height: 24),
                  
                  _loading
                      ? const CircularProgressIndicator(color: Color(0xFFF29824))
                      : SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _register,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFF29824),
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                            child: const Text('Ro‘yxatdan o‘tish',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                  const SizedBox(height: 16),
                  
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Login sahifasiga qaytish',
                        style: TextStyle(color: Color(0xFFF29824))),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}