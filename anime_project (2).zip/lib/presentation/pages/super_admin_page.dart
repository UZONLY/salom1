// lib/presentation/pages/super_admin_page.dart
// ⭐️ BU FAYLNI HAM QAYTA YARATING ⭐️

import 'package:flutter/material.dart';
import 'admin_add_admin_page.dart';
import 'admin_top_up_page.dart';

class SuperAdminPage extends StatelessWidget {
  const SuperAdminPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Super Admin Boshqaruvi',
            style: TextStyle(
                color: Colors.redAccent,
                fontSize: 22,
                fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 24),

          // Yangi admin qo'shish tugmasi
          ElevatedButton.icon(
            icon: const Icon(Icons.person_add),
            label: const Text('Yangi Admin Qo‘shish'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFF29824),
              foregroundColor: Colors.black,
              minimumSize: const Size(double.infinity, 50),
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AdminAddAdminPage()),
              );
            },
          ),

          const SizedBox(height: 16),

          // Foydalanuvchi hisobini to'ldirish tugmasi
          ElevatedButton.icon(
            icon: const Icon(Icons.attach_money),
            label: const Text('Foydalanuvchi Hisobini To‘ldirish'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
              minimumSize: const Size(double.infinity, 50),
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AdminTopUpPage()),
              );
            },
          ),

          const SizedBox(height: 24),
          const Card(
            color: Color(0xFF2F323E),
            child: ListTile(
              leading: Icon(Icons.bar_chart, color: Colors.green),
              title: Text('Statistika (Backend)',
                  style: TextStyle(color: Colors.white)),
              subtitle: Text('Umumiy daromad va statistika (/stats)',
                  style: TextStyle(color: Colors.white70)),
            ),
          ),
        ],
      ),
    );
  }
}
