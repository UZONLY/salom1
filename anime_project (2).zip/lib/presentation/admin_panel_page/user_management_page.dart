import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart';

class UserManagementPage extends StatelessWidget {
  const UserManagementPage({super.key});

  void _addBalance(String userId, double amount, BuildContext context) {
    final user = usersProfiles.values.firstWhere((u) => u.userId == userId, orElse: () => usersProfiles.values.first);
    user.balance += amount;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$amount so‘m qo‘shildi')));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Foydalanuvchilar', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: usersProfiles.length,
              itemBuilder: (ctx, i) {
                final user = usersProfiles.values.elementAt(i);
                return Card(
                  color: const Color(0xFF2F323E),
                  child: ListTile(
                    leading: CircleAvatar(child: Text(user.email[0].toUpperCase())),
                    title: Text(user.email, style: const TextStyle(color: Colors.white)),
                    subtitle: Text('Balans: ${user.balance.toStringAsFixed(0)} so‘m'),
                    trailing: PopupMenuButton(
                      itemBuilder: (_) => [
                        PopupMenuItem(child: const Text('100,000 qo‘shish'), onTap: () => _addBalance(user.userId, 100000, ctx)),
                        const PopupMenuItem(child: Text('Bloklash')),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}