import 'package:anime_project/presentation/pages/admin_panel_page.dart';
import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart';

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});

  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  String? _error;

  void _login() {
    final email = _emailCtrl.text.trim();
    final pass = _passCtrl.text.trim();

    final user = usersProfiles[email];
    if (user == null) {
      setState(() => _error = 'Admin topilmadi');
      return;
    }
    if (usersCredentials[email] != pass) {
      setState(() => _error = 'Parol noto‘g‘ri');
      return;
    }

    currentUser.value = user;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const AdminPanelPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      appBar: AppBar(
        backgroundColor: const Color(0xFF252831),
        title: const Text('Admin Kirish', style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.admin_panel_settings, size: 80, color: Color(0xFFF29824)),
            const SizedBox(height: 30),
            TextField(
              controller: _emailCtrl,
              keyboardType: TextInputType.emailAddress,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Email',
                labelStyle: TextStyle(color: Colors.white70),
                prefixIcon: Icon(Icons.email, color: Color(0xFFF29824)),
                enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFF29824))),
                focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFF29824), width: 2)),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _passCtrl,
              obscureText: true,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Parol',
                labelStyle: TextStyle(color: Colors.white70),
                prefixIcon: Icon(Icons.lock, color: Color(0xFFF29824)),
                enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFF29824))),
                focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFF29824), width: 2)),
              ),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(_error!, style: const TextStyle(color: Colors.redAccent, fontSize: 14)),
              ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _login,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF29824),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('Kirish', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}