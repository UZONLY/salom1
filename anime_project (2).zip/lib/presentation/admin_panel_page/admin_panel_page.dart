// presentation/pages/admin_panel_page.dart
import 'package:anime_project/presentation/pages/admin_add_anime_page.dart';
import 'package:anime_project/presentation/pages/manage_reklama_page.dart';
import 'package:anime_project/presentation/pages/super_admin_page.dart';
import 'package:anime_project/presentation/pages/user_management_page.dart';
import 'package:flutter/material.dart';
import '../../data/datasources/in_memory_datasource.dart';

class AdminPanelPage extends StatefulWidget {
  const AdminPanelPage({super.key});

  @override
  State<AdminPanelPage> createState() => _AdminPanelPageState();
}

class _AdminPanelPageState extends State<AdminPanelPage> {
  int _selectedIndex = 0;

  late final List<Widget> _pages;
  late final List<BottomNavigationBarItem> _navItems;

  @override
  void initState() {
    super.initState();
    // Super adminni tekshirish
    final isSuperAdmin = currentUser.value?.email == 'shodiyor1@example.com';

    // Admin uchun mavjud sahifalar ro'yxati
    _pages = [
      _buildDashboard(), // Asosiy statistika sahifasi
      const AdminAddAnimePage(), // Anime qo'shish sahifasi
      const ManageReklamaPage(), // Reklamani boshqarish
      const UserManagementPage(), // Foydalanuvchilarni boshqarish
      if (isSuperAdmin) const SuperAdminPage(), // Agar Super Admin bo'lsa
    ];

    // Pastki menyu tugmalari
    _navItems = [
      const BottomNavigationBarItem(
          icon: Icon(Icons.dashboard), label: 'Dashboard'),
      const BottomNavigationBarItem(
          icon: Icon(Icons.movie_creation), label: 'Anime'),
      const BottomNavigationBarItem(
          icon: Icon(Icons.campaign), label: 'Reklama'),
      const BottomNavigationBarItem(
          icon: Icon(Icons.people), label: 'Foydalanuvchilar'),
      if (isSuperAdmin)
        const BottomNavigationBarItem(
            icon: Icon(Icons.security, color: Colors.red), label: 'Super Admin'),
    ];
  }

  // Dashboard (Statistika) vidjeti
  Widget _buildDashboard() {
    final totalAnimes = demoAnimes.length;
    final freeAnimes = demoAnimes.where((a) => a.price == 0).length;
    final paidAnimes = totalAnimes - freeAnimes;
    final totalUsers = usersProfiles.length;
    
    // Daromad va ko'rishlarni hisoblash
    final totalIncome = demoAnimes.fold<double>(
        0, (sum, a) => sum + (a.price * a.purchaseTimestamps.length));
    final totalViews = demoAnimes.fold<int>(
        0, (sum, a) => sum + a.viewTimestamps.length);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Admin Paneli',
            style: TextStyle(
                color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'Xush kelibsiz, ${currentUser.value?.email}',
            style: const TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 24),
          _statCard(
              'Jami animelar', totalAnimes.toString(), Icons.movie),
          _statCard(
              'Bepul animelar', freeAnimes.toString(), Icons.free_breakfast),
          _statCard(
              'Pullik animelar', paidAnimes.toString(), Icons.attach_money),
          _statCard(
              'Foydalanuvchilar', totalUsers.toString(), Icons.person),
          _statCard(
              'Jami daromad', '${totalIncome.toStringAsFixed(0)} so‘m', Icons.trending_up),
          _statCard(
              'Ko‘rishlar soni', totalViews.toString(), Icons.remove_red_eye),
        ],
      ),
    );
  }

  // Statistika uchun yordamchi kartochka
  Widget _statCard(String title, String value, IconData icon) {
    return Card(
      color: const Color(0xFF2F323E),
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFFF29824)),
        title: Text(title,
            style: const TextStyle(color: Colors.white70, fontSize: 14)),
        trailing: Text(
          value,
          style: const TextStyle(
              color: Color(0xFFF29824),
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF252831),
      // AppBar (yuqori panel) o'chirilgan, chunki bu sahifa MainMenu ichida ko'rsatiladi
      // va MainMenu'ning o'zida AppBar mavjud.
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF2F323E),
        selectedItemColor: const Color(0xFFF29824),
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (i) => setState(() => _selectedIndex = i),
        items: _navItems,
      ),
    );
  }
}