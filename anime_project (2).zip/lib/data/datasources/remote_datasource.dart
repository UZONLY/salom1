import 'package:anime_project/domain/entities/anime.dart';
import '../../services/api_service.dart';

class RemoteDataSource {
  static Future<List<Anime>> getAnimes() async {
    try {
      final list = await ApiService.getAnimes();
      return list.map((e) => Anime.fromJson(e)).toList();
    } catch (e) {
      print('RemoteDataSource.getAnimes xato: $e');
      return [];
    }
  }

  static Future<Anime?> getAnimeById(String id) async {
    try {
      final data = await ApiService.getAnimeById(id);
      return data != null ? Anime.fromJson(data) : null;
    } catch (e) {
      print('getAnimeById xato: $e');
      return null;
    }
  }

  static Future<Anime?> addAnime(Anime anime) async {
    final data = {
      'title': anime.title,
      'genre': anime.genre,
      'desc': anime.desc,
      'price': anime.price,
      'posterUrl': anime.thumbnailUrl, // backendda posterUrl
      'addedBy': anime.adminId,
    };

    final result = await ApiService.addAnime(data);
    if (result != null) {
      return Anime.fromJson(result);
    }
    return null;
  }

  static Future<bool> deleteAnime(String id) async {
    return await ApiService.deleteAnime(id);
  }
}