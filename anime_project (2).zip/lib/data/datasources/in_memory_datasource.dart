// lib/data/datasources/in_memory_datasource.dart
import 'package:flutter/foundation.dart';
import '../../domain/entities/anime.dart';
import '../../domain/entities/user_profile.dart';

ValueNotifier<UserProfile?> currentUser = ValueNotifier(null);

Map<String, String> usersCredentials = {
  'shodiyor1@example.com': 'shodiyor1!',
};

Map<String, UserProfile> usersProfiles = {
  'shodiyor1@example.com': UserProfile(
    name: 'Shodiyor',
    email: 'shodiyor1@example.com',
    userId: 'admin_001',
    balance: 1000000.0,
    purchasedAnimes: [],
    
    dub: 'AniBla',
    hasFreeWatchUsed: false,
    profileImagePath: null, 
    password: 'shodiyor1!',
  ),
};

ValueNotifier<List<Anime>> banners = ValueNotifier([]);

List<Anime> demoAnimes = [
  Anime(
    title: 'Naruto Shippuden',
    genre: 'Action, Adventure',
    desc: 'Naruto Uzumaki Akatsuki guruhiga qarshi kurashadi va Hokage bo‘lishni orzu qiladi.',
    price: 0.0,
    episodeUrls: [
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    ],
    thumbnailUrl: 'https://upload.wikimedia.org/wikipedia/en/9/94/NarutoCoverTankobon1.jpg',
    bannerUrl: 'https://wallpapercave.com/wp/wp1917154.jpg',
    adminId: 'admin_001',
    purchaseTimestamps: [],
    viewTimestamps: [],
    dub: 'Studio Pierrot',
    advertiseBanner: false,
    createdAt: DateTime(2023, 1, 15),
  ),
  // Boshqa animelar...
];

void initBanners() {
  banners.value = demoAnimes.where((a) => a.price == 0.0).toList();
}