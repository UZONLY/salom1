// import '../../data/datasources/in_memory_datasource.dart';
// import '../entities/anime.dart';
// import '../entities/user_profile.dart';

// void addAnime({
//   required String title,
//   required String genre,
//   required String desc,
//   required String dub,
//   required double price,
//   required List<String> episodeUrls,
//   required String thumbnailUrl,
//   required String bannerUrl,
//   required String adminId,
//   required bool advertiseBanner,
//   required UserProfile currentUser,
// }) {
//   final anime = Anime(
//     title: title,
//     dub: dub,
//     genre: genre,
//     desc: desc,
//     price: price,
//     episodeUrls: List.from(episodeUrls),
//     thumbnailUrl: thumbnailUrl,
//     bannerUrl: bannerUrl,
//     adminId: adminId,
//     isAdvertised: advertiseBanner,
//   );

//   demoAnimes.add(anime);
//   if (advertiseBanner) {
//     banners.value = [...banners.value, anime];
//     final owner = usersProfiles['shodiyor1@example.com']!;
//     owner.balance += 500;
//     usersProfiles[owner.email] = owner;
//   }
// }
import '../entities/anime.dart';
import '../entities/user_profile.dart';
import '../../data/datasources/in_memory_datasource.dart';

void addAnime({
  required String title,
  required String genre,
  required String desc,
  required String dub,
  required double price,
  required List<String> episodeUrls,
  required String thumbnailUrl,
  required String bannerUrl,
  required String adminId,
  required bool advertiseBanner,
  required UserProfile currentUser,
}) {
  // Faqat haqiqiy admin qo‘sha oladi
  if (!currentUser.isRealAdmin) {
    print("Ruxsat yo‘q: Siz admin emassiz!");
    return;
  }

  final newAnime = Anime(
    title: title,
    genre: genre,
    desc: desc,
    dub: dub,
    price: price,
    episodeUrls: episodeUrls,
    thumbnailUrl: thumbnailUrl,
    bannerUrl: bannerUrl,
    adminId: adminId,
    advertiseBanner: advertiseBanner,
    purchaseTimestamps: [],
    viewTimestamps: [],
    createdAt: DateTime.now(),
  );

  demoAnimes.add(newAnime);

  if (advertiseBanner) {
    if (currentUser.balance >= 50000) {
      currentUser.balance -= 50000;
      banners.value = [...banners.value, newAnime];
      usersProfiles[currentUser.email] = currentUser;
      print("Reklama qo‘shildi! Balans: ${currentUser.balance}");
    } else {
      print("Balans yetarli emas reklama uchun");
    }
  }
}