// domain/use_cases/watch_anime_use_case.dart
import 'package.flutter/material.dart'; // <-- BuildContext uchun import qo'shildi
import '../../data/datasources/in_memory_datasource.dart';
import '../entities/anime.dart';
import '../entities/user_profile.dart';

// ⭐️⭐️⭐️ TUZATISH: 'BuildCocontext' -> 'BuildContext context' ⭐️⭐️⭐️
String? tryWatch(BuildContext context, Anime anime, UserProfile? user) {
  if (user == null) {
    return 'Iltimos tizimga kiring';
  }

  // 1. Agar sotib olgan bo'lsa
  if (user.purchasedAnimes.contains(anime.title)) {
    anime.viewTimestamps.add(DateTime.now());
    return null; // Tomosha qilishga ruxsat
  }

  // 2. Agar bepul tomosha qilish haqqi bor bo'lsa
  if (!user.hasFreeWatchUsed) {
    user.hasFreeWatchUsed = true;
    user.purchasedAnimes.add(anime.title as String);
    anime.purchaseTimestamps.add(DateTime.now());
    anime.viewTimestamps.add(DateTime.now());
    usersProfiles[user.email] = user; // Foydalanuvchi ma'lumotini yangilash

    // Adminlarga pul o'tkazish
    try {
      final owner = usersProfiles['shodiyor1@example.com']!;
      owner.balance += 900;

      // Reklama puli (agar mavjud bo'lsa) - XATO TUZATILDI
      // Bu yerda egasiga 50,000 QO'SHILMAYDI. 
      // Bu pul anime qo'shilganda yechib olingan bo'lishi kerak.
      // Asl kodingizdagi xato mantiq olib tashlandi.
      
      final admin = usersProfiles.values
          .firstWhere((u) => u.userId == anime.adminId);
      admin.balance += 2000;
      
      usersProfiles[owner.email] = owner;
      usersProfiles[admin.email] = admin;
    } catch (e) {
      print("Admin topishda xato: $e");
      // Bu xato foydalanuvchiga ko'rsatilmasligi kerak, lekin log uchun muhim
    }

    return 'Bepul tomosha ishlatildi va anime sotib olindi';
  }

  // 3. Agar balansi yetsa
  if (user.balance >= anime.price) {
    user.balance -= anime.price;
    user.purchasedAnimes.add(anime.title as String);
    anime.purchaseTimestamps.add(DateTime.now());
    anime.viewTimestamps.add(DateTime.now());
    
    // Adminlarga pul o'tkazish
    try {
      final owner = usersProfiles['shodiyor1@example.com']!;
      owner.balance += 900;
      
      // Bu yerda ham reklama puli qo'shilmaydi.

      final admin = usersProfiles.values
          .firstWhere((u) => u.userId == anime.adminId);
      admin.balance += 2000;
      
      usersProfiles[owner.email] = owner;
      usersProfiles[admin.email] = admin;
    } catch (e) {
       print("Admin topishda xato: $e");
    }
    
    usersProfiles[user.email] = user; // Foydalanuvchi balansini yangilash
    
    return 'Anime sotib olindi va tomosha uchun ochildi';
  }

  // 4. Puli yetmasa
  return 'Hisob yetarli emas';
}