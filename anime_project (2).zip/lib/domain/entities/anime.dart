// lib/domain/entities/anime.dart
// ⭐️⭐️⭐️ BU KOD SHU YERDA BO'LISHI KERAK ⭐️⭐️⭐️

class Anime {
  final String title;
  final String genre;
  final String desc;
  final double price;
  final List<String> episodeUrls;
  final String thumbnailUrl;
  final String? bannerUrl;
  final String adminId;
  final List<DateTime> purchaseTimestamps;
  final List<DateTime> viewTimestamps;
  final String dub;
  late final bool advertiseBanner;
  final DateTime createdAt;

  String? id;

  Anime({
    this.id,
    required this.title,
    required this.genre,
    required this.desc,
    required this.price,
    required this.episodeUrls,
    required this.thumbnailUrl,
    this.bannerUrl,
    required this.adminId,
    required this.purchaseTimestamps,
    required this.viewTimestamps,
    required this.dub,
    required this.advertiseBanner,
    required this.createdAt,
  });

  // JSON → Anime
  factory Anime.fromJson(Map<String, dynamic> json) {
    // Backend 'id' yoki '_id' yuborishi mumkin
    final String? animeId = json['id'] ?? json['_id'];

    return Anime(
      id: animeId,
      title: json['title'] ?? 'Nomsiz',
      genre: json['genre'] ?? 'Noma\'lum janr',
      desc: json['desc'] ?? json['description'] ?? 'Tavsif yo\'q',
      price: (json['price'] ?? 0.0).toDouble(),
      episodeUrls: List<String>.from(json['episodeUrls'] ?? []),
      thumbnailUrl: json['thumbnailUrl'] ??
          json['posterUrl'] ??
          '', // posterUrl ni ham tekshiradi
      bannerUrl: json['bannerUrl'],
      adminId: json['adminId'] ??
          json['added_by'] ??
          '0', // added_by ni ham tekshiradi
      purchaseTimestamps: (json['purchaseTimestamps'] as List? ?? [])
          .map((t) => DateTime.tryParse(t.toString()) ?? DateTime.now())
          .toList(),
      viewTimestamps: (json['viewTimestamps'] as List? ?? [])
          .map((t) => DateTime.tryParse(t.toString()) ?? DateTime.now())
          .toList(),
      dub: json['dub'] ??
          json['dubbing_name'] ??
          'Noma\'lum', // dubbing_name ni ham tekshiradi
      advertiseBanner: json['advertiseBanner'] ?? false,
      createdAt: DateTime.tryParse(
              json['createdAt'] ?? DateTime.now().toIso8601String()) ??
          DateTime.now(),
    );
  }

  // Anime → JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'genre': genre,
      'desc': desc,
      'price': price,
      'episodeUrls': episodeUrls,
      'thumbnailUrl': thumbnailUrl,
      'bannerUrl': bannerUrl,
      'adminId': adminId,
      'purchaseTimestamps':
          purchaseTimestamps.map((t) => t.toIso8601String()).toList(),
      'viewTimestamps': viewTimestamps.map((t) => t.toIso8601String()).toList(),
      'dub': dub,
      'advertiseBanner': advertiseBanner,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}
