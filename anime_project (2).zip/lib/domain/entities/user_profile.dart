class UserProfile {
  final String name;
  final String email;
  final String userId;
  final String password;           // Majburiy
  double balance;
  final List<String> purchasedAnimes;
  final String dub;
  bool hasFreeWatchUsed;
  String? profileImagePath;



bool get isRealAdmin {
  return email == 'shodiyor1@example.com' && password == 'shodiyor1!';
}

  UserProfile({
    required this.name,
    required this.email,
    required this.userId,
    required this.password,
    this.balance = 0.0,
    this.purchasedAnimes = const [],
    this.dub = 'uz',
    this.hasFreeWatchUsed = false,
    this.profileImagePath,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      name: json['name'] ?? json['email']?.split('@').first ?? 'User',
      email: json['email'] ?? '',
      userId: json['userId'] ?? json['_id'] ?? json['id'] ?? '',
      password: json['password'] ?? '', // Backenddan kelmasa ham bo‘sh bo‘ladi
      balance: (json['balance'] ?? 0).toDouble(),
      purchasedAnimes: List<String>.from(json['purchasedAnimes'] ?? []),
      dub: json['dub'] ?? 'uz',
      hasFreeWatchUsed: json['hasFreeWatchUsed'] ?? false,
      profileImagePath: json['profileImagePath'],
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'userId': userId,
        'password': password,
        'balance': balance,
        'purchasedAnimes': purchasedAnimes,
        'dub': dub,
        'hasFreeWatchUsed': hasFreeWatchUsed,
        'profileImagePath': profileImagePath,
      };
}