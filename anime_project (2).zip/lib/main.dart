// lib/main.dart
// ⭐️⭐️⭐️ BU KOD SHU YERDA BO'LISHI KERAK ⭐️⭐️⭐️

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:anime_project/presentation/pages/login_page.dart';
import 'package:anime_project/presentation/pages/main_menu.dart';
import 'package:anime_project/domain/entities/user_profile.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:anime_project/data/datasources/in_memory_datasource.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global =
      MyHttpOverrides(); // SSL sertifikat xatolarini chetlab o'tish uchun
  final prefs = await SharedPreferences.getInstance();

  // "user" json stringni olish
  final userJson = prefs.getString(
      'saved_user'); // ⭐️ 'user' -> 'saved_user' ga o'zgartirildi (ApiService ga mos)
  UserProfile? user;

  if (userJson != null) {
    try {
      user = UserProfile.fromJson(jsonDecode(userJson));
      currentUser.value = user; // Global 'currentUser' ni yangilash
    } catch (e) {
      print('Saqlangan foydalanuvchini o\'qishda xato: $e');
      user = null; // Agar xato bo'lsa, logindan boshlash
    }
  }

  runApp(MyApp(user: user));
}

class MyApp extends StatelessWidget {
  final UserProfile? user;
  const MyApp({super.key, this.user});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Anime TV',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFF252831),
        // Butun ilova uchun yagona rang sxemasi (ixtiyoriy)
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFF29824),
          brightness: Brightness.dark,
          background: const Color(0xFF252831),
        ),
        useMaterial3: true,
      ),
      // Agar foydalanuvchi saqlangan bo'lsa `MainMenu`ga, aks holda `LoginPage`ga o'tadi
      home: user != null ? const MainMenu() : const LoginPage(),
    );
  }
}

// SSL/TLS sertifikat muammolarini (masalan, "CERTIFICATE_VERIFY_FAILED")
// e'tiborsiz qoldirish uchun
class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}
